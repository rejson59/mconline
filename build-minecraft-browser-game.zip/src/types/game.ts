export enum BlockType {
  AIR = 0,
  GRASS = 1,
  DIRT = 2,
  STONE = 3,
  COBBLESTONE = 4,
  OAK_LOG = 5,
  OAK_LEAVES = 6,
  OAK_PLANKS = 7,
  SAND = 8,
  SANDSTONE = 9,
  GLASS = 10,
  WATER = 11,
  BEDROCK = 12,
  COAL_ORE = 13,
  IRON_ORE = 14,
  GOLD_ORE = 15,
  DIAMOND_ORE = 16,
  REDSTONE_ORE = 17,
  BRICKS = 18,
  BOOKSHELF = 19,
  TNT = 20,
  TORCH = 21,
  CRAFTING_TABLE = 22,
  FURNACE = 23,
  GLOWSTONE = 24,
  SNOW_GRASS = 25,
  BIRCH_LOG = 26,
  BIRCH_LEAVES = 27,
  MOSSY_COBBLESTONE = 28,
  OBSIDIAN = 29,
  FLOWER_RED = 30,
  FLOWER_YELLOW = 31,
}

export type ToolType = 'pickaxe' | 'axe' | 'shovel' | 'sword' | 'none';
export type ToolMaterial = 'wood' | 'stone' | 'iron' | 'diamond' | 'none';

export interface ItemDef {
  id: string;
  name: string;
  namePl: string;
  isBlock: boolean;
  blockType?: BlockType;
  toolType?: ToolType;
  toolMaterial?: ToolMaterial;
  miningSpeedMultiplier?: number;
  attackDamage?: number;
  maxDurability?: number;
  durability?: number;
  foodRestore?: number;
  color?: string;
  icon?: string;
}

export interface BlockDef {
  id: BlockType;
  name: string;
  namePl: string;
  hardness: number; // 0 = instant, 1 = normal, 5 = hard, -1 = unbreakable
  tool: ToolType;
  transparent?: boolean;
  translucent?: boolean;
  lightEmission?: number; // 0 - 15
  isPlant?: boolean;
  isLiquid?: boolean;
  sound: 'grass' | 'dirt' | 'stone' | 'wood' | 'sand' | 'glass' | 'wool';
  dropItem: string;
  dropCount?: number;
  topTexture: string;
  sideTexture: string;
  bottomTexture: string;
  frontTexture?: string;
}

export interface InventorySlot {
  itemId: string;
  count: number;
}

export type GameMode = 'survival' | 'creative';

export interface PlayerStats {
  health: number; // 0 to 20
  maxHealth: number;
  hunger: number; // 0 to 20
  maxHunger: number;
  air: number; // 0 to 20
  maxAir: number;
  isFlying: boolean;
  isSprinting: boolean;
  isSneaking: boolean;
  isUnderwater: boolean;
  gameMode: GameMode;
  selectedHotbarIndex: number; // 0 to 8
}

export interface MobEntity {
  id: string;
  type: 'pig' | 'sheep' | 'cow' | 'zombie';
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  yaw: number;
  pitch: number;
  health: number;
  maxHealth: number;
  animTime: number;
  walkCycle: number;
  isHurt: number; // hurt timer
  mesh?: any;
}

export interface DroppedItem {
  id: string;
  itemId: string;
  count: number;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  age: number;
  mesh?: any;
}

export interface WorldSettings {
  timeOfDay: number; // 0 to 24000 (6000 = noon, 12000 = sunset, 18000 = midnight, 0 = sunrise)
  timeSpeed: number; // multiplier
  renderDistance: number; // in chunks (e.g. 3 to 6)
  fov: number; // default 75
  mouseSensitivity: number;
  soundVolume: number;
  musicVolume: number;
  showF3: boolean;
  chunkCulling: boolean;
  fogEnabled: boolean;
  seed: number;
}

export interface CraftingRecipe {
  pattern: (string | null)[][];
  result: { itemId: string; count: number };
  isShapeless?: boolean;
}
