import { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { BlockType, PlayerStats, InventorySlot, WorldSettings, GameMode } from './types/game';
import { WorldManager, RaycastResult } from './engine/world';
import { PhysicsController } from './engine/physics';
import { SoundManager } from './engine/audio';
import { EntityManager } from './engine/mobs';
import { BLOCK_DEFS, ITEMS } from './engine/blocks';
import { TextureManager } from './engine/textures';
import { HUD } from './components/HUD';
import { InventoryModal } from './components/InventoryModal';
import { DebugF3 } from './components/DebugF3';
import { PauseMenu } from './components/PauseMenu';
import { ChatBox, ChatMessage } from './components/ChatBox';
import { HeldItemArm } from './components/HeldItemArm';

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);

  // Core references
  const worldRef = useRef<WorldManager | null>(null);
  const physicsRef = useRef<PhysicsController | null>(null);
  const entityMgrRef = useRef<EntityManager | null>(null);
  const soundMgrRef = useRef<SoundManager>(SoundManager.getInstance());
  const textureMgrRef = useRef<TextureManager>(TextureManager.getInstance());
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sunLightRef = useRef<THREE.DirectionalLight | null>(null);
  const ambientLightRef = useRef<THREE.AmbientLight | null>(null);
  const sunMeshRef = useRef<THREE.Mesh | null>(null);
  const moonMeshRef = useRef<THREE.Mesh | null>(null);

  // Block Highlight Outline & Break Crack Overlay
  const highlightBoxRef = useRef<THREE.LineSegments | null>(null);
  const breakOverlayRef = useRef<THREE.Mesh | null>(null);

  // Mining state
  const isMouseDownRef = useRef(false);
  const miningTimeRef = useRef(0);
  const miningTargetRef = useRef<{ x: number; y: number; z: number; block: BlockType } | null>(null);
  const lastHitSoundTimeRef = useRef(0);
  const footstepTimerRef = useRef(0);
  const prevVyRef = useRef(0);
  const mobSoundTimerRef = useRef(0);

  // Player controls & camera rotation
  const yawRef = useRef<number>(0);
  const pitchRef = useRef<number>(0);
  const isLockedRef = useRef<boolean>(false);
  const keysRef = useRef<Record<string, boolean>>({});

  // Swing & walking animation state for UI
  const [isSwinging, setIsSwinging] = useState(false);
  const [isWalking, setIsWalking] = useState(false);
  const swingTimerRef = useRef<any>(null);

  // Settings
  const [settings, setSettings] = useState<WorldSettings>({
    timeOfDay: 6000, // Day
    timeSpeed: 1.0,
    renderDistance: 3,
    fov: 75,
    mouseSensitivity: 0.0022,
    soundVolume: 0.5,
    musicVolume: 0.3,
    showF3: false,
    chunkCulling: true,
    fogEnabled: true,
    seed: 1337,
  });

  // Player Stats
  const [stats, setStats] = useState<PlayerStats>({
    health: 20,
    maxHealth: 20,
    hunger: 20,
    maxHunger: 20,
    air: 20,
    maxAir: 20,
    isFlying: false,
    isSprinting: false,
    isSneaking: false,
    isUnderwater: false,
    gameMode: 'survival',
    selectedHotbarIndex: 0,
  });

  // Hotbar (9 slots)
  const [hotbar, setHotbar] = useState<InventorySlot[]>([
    { itemId: 'item_wooden_pickaxe', count: 1 },
    { itemId: 'item_wooden_axe', count: 1 },
    { itemId: 'item_wooden_sword', count: 1 },
    { itemId: 'block_oak_planks', count: 32 },
    { itemId: 'block_torch', count: 16 },
    { itemId: 'item_apple', count: 8 },
    { itemId: 'block_tnt', count: 8 },
    { itemId: 'block_sand', count: 16 },
    { itemId: 'block_crafting_table', count: 1 },
  ]);

  // Main Inventory (27 slots)
  const [inventory, setInventory] = useState<InventorySlot[]>(() => {
    const arr: InventorySlot[] = new Array(27).fill(null).map(() => ({ itemId: '', count: 0 }));
    arr[0] = { itemId: 'item_stick', count: 12 };
    arr[1] = { itemId: 'block_cobblestone', count: 24 };
    arr[2] = { itemId: 'item_coal', count: 8 };
    return arr;
  });

  // UI Modals
  const [isInventoryOpen, setIsInventoryOpen] = useState(false);
  const [isCraftingTableOpen, setIsCraftingTableOpen] = useState(false);
  const [isPauseMenuOpen, setIsPauseMenuOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    { id: '1', text: 'Witaj w Minecraft Web 3D! Naciśnij [E], aby otworzyć ekwipunek.', color: '#ffff55' },
    { id: '2', text: 'Naciśnij [F3] po statystyki, [ESC] po menu i zapisywanie gry.', color: '#55ff55' },
    { id: '3', text: 'Wpisz [/help] w czacie [T], aby zobaczyć listę komend.', color: '#55ffff' },
  ]);

  // Diagnostics & Raycast
  const [fps, setFps] = useState(60);
  const [targetBlock, setTargetBlock] = useState<RaycastResult | null>(null);
  const [currentBiome, setCurrentBiome] = useState('plains');

  // Trigger weapon swing
  const triggerSwing = useCallback(() => {
    setIsSwinging(true);
    if (swingTimerRef.current) clearTimeout(swingTimerRef.current);
    swingTimerRef.current = setTimeout(() => setIsSwinging(false), 220);
  }, []);

  // Update Inventory Helper
  const handleUpdateInventory = useCallback((newInv: InventorySlot[], newHotbar: InventorySlot[]) => {
    setInventory(newInv);
    setHotbar(newHotbar);
  }, []);

  // Add Item to Inventory/Hotbar Helper
  const addItemToInventory = useCallback((itemId: string, count: number = 1) => {
    setHotbar(prevHotbar => {
      const hb = [...prevHotbar];
      // Try adding to existing hotbar stack
      const existingHbIdx = hb.findIndex(s => s.itemId === itemId && s.count < 64);
      if (existingHbIdx !== -1) {
        hb[existingHbIdx] = { ...hb[existingHbIdx], count: hb[existingHbIdx].count + count };
        return hb;
      }
      // Try empty hotbar slot
      const emptyHbIdx = hb.findIndex(s => !s.itemId);
      if (emptyHbIdx !== -1) {
        hb[emptyHbIdx] = { itemId, count };
        return hb;
      }

      // Otherwise put into main inventory
      setInventory(prevInv => {
        const inv = [...prevInv];
        const existingInvIdx = inv.findIndex(s => s.itemId === itemId && s.count < 64);
        if (existingInvIdx !== -1) {
          inv[existingInvIdx] = { ...inv[existingInvIdx], count: inv[existingInvIdx].count + count };
        } else {
          const emptyInvIdx = inv.findIndex(s => !s.itemId);
          if (emptyInvIdx !== -1) {
            inv[emptyInvIdx] = { itemId, count };
          }
        }
        return inv;
      });

      return hb;
    });
  }, []);

  // Save / Load World from LocalStorage
  const handleSaveWorld = useCallback(() => {
    if (!physicsRef.current) return;
    const saveObj = {
      pos: physicsRef.current.position.toArray(),
      stats,
      hotbar,
      inventory,
      settings,
    };
    localStorage.setItem('minecraft_web_save', JSON.stringify(saveObj));
  }, [stats, hotbar, inventory, settings]);

  const handleLoadWorld = useCallback(() => {
    try {
      const data = localStorage.getItem('minecraft_web_save');
      if (data && physicsRef.current) {
        const parsed = JSON.parse(data);
        physicsRef.current.position.fromArray(parsed.pos);
        if (parsed.stats) setStats(parsed.stats);
        if (parsed.hotbar) setHotbar(parsed.hotbar);
        if (parsed.inventory) setInventory(parsed.inventory);
        if (parsed.settings) setSettings(parsed.settings);
      }
    } catch (e) {
      console.error(e);
    }
  }, []);

  // Reset World / Change Seed
  const handleResetWorld = useCallback((newSeed: number) => {
    if (!worldRef.current || !physicsRef.current) return;
    setSettings(prev => ({ ...prev, seed: newSeed }));
    worldRef.current.setSeed(newSeed);
    physicsRef.current.position.set(0, 36, 0);
    physicsRef.current.velocity.set(0, 0, 0);
  }, []);

  // Chat Command Execution
  const handleExecuteCommand = useCallback((cmd: string, args: string[]) => {
    const addMsg = (text: string, color: string = '#ffffff') => {
      setChatMessages(prev => [...prev, { id: Math.random().toString(), text, color }]);
    };

    switch (cmd) {
      case 'help':
        addMsg('=== Dostępne komendy Minecraft ===', '#ffff55');
        addMsg('/gamemode <creative|survival> - zmiana trybu gry', '#aaaaaa');
        addMsg('/time set <day|noon|night|midnight> - zmiana pory dnia', '#aaaaaa');
        addMsg('/give <przedmiot> [ilość] - dodanie przedmiotu (np. /give diamond 64)', '#aaaaaa');
        addMsg('/tp <x> <y> <z> - teleportacja na współrzędne', '#aaaaaa');
        addMsg('/spawn mob <pig|sheep|zombie> - stworzenie stworzenia', '#aaaaaa');
        addMsg('/clear - wyczyszczenie ekwipunku', '#aaaaaa');
        addMsg('/kill - samobójstwo gracza', '#aaaaaa');
        break;

      case 'gamemode':
      case 'gm':
        const modeArg = args[0]?.toLowerCase();
        if (modeArg === 'c' || modeArg === 'creative' || modeArg === '1') {
          setStats(s => ({ ...s, gameMode: 'creative', isFlying: true }));
          addMsg('Ustawiono tryb gry na: Kreatywny (Creative Mode)', '#55ff55');
        } else if (modeArg === 's' || modeArg === 'survival' || modeArg === '0') {
          setStats(s => ({ ...s, gameMode: 'survival', isFlying: false }));
          addMsg('Ustawiono tryb gry na: Przetrwanie (Survival Mode)', '#55ff55');
        } else {
          addMsg('Użycie: /gamemode <creative|survival>', '#ff5555');
        }
        break;

      case 'time':
        if (args[0] === 'set') {
          const tArg = args[1]?.toLowerCase();
          if (tArg === 'day') setSettings(s => ({ ...s, timeOfDay: 1000 }));
          else if (tArg === 'noon') setSettings(s => ({ ...s, timeOfDay: 6000 }));
          else if (tArg === 'sunset') setSettings(s => ({ ...s, timeOfDay: 12000 }));
          else if (tArg === 'night') setSettings(s => ({ ...s, timeOfDay: 14000 }));
          else if (tArg === 'midnight') setSettings(s => ({ ...s, timeOfDay: 18000 }));
          else if (!isNaN(parseInt(tArg))) setSettings(s => ({ ...s, timeOfDay: parseInt(tArg) % 24000 }));
          addMsg(`Pora dnia ustawiona na: ${args[1]}`, '#55ff55');
        }
        break;

      case 'give':
        const itemArg = args[0]?.toLowerCase();
        const countArg = parseInt(args[1]) || 1;
        const matchingId = Object.keys(ITEMS).find(k =>
          k.toLowerCase().includes(itemArg) || ITEMS[k].name.toLowerCase().includes(itemArg) || ITEMS[k].namePl.toLowerCase().includes(itemArg)
        );
        if (matchingId) {
          addItemToInventory(matchingId, countArg);
          addMsg(`Przyznano ${countArg}x [${ITEMS[matchingId].namePl}] graczowi Steve`, '#55ff55');
        } else {
          addMsg(`Nie znaleziono przedmiotu: ${itemArg}`, '#ff5555');
        }
        break;

      case 'tp':
        if (args.length >= 3 && physicsRef.current) {
          const tx = parseFloat(args[0]);
          const ty = parseFloat(args[1]);
          const tz = parseFloat(args[2]);
          physicsRef.current.position.set(tx, ty, tz);
          physicsRef.current.velocity.set(0, 0, 0);
          addMsg(`Przeteleportowano do ${tx}, ${ty}, ${tz}`, '#55ff55');
        } else {
          addMsg('Użycie: /tp <x> <y> <z>', '#ff5555');
        }
        break;

      case 'clear':
        setHotbar(new Array(9).fill(null).map(() => ({ itemId: '', count: 0 })));
        setInventory(new Array(27).fill(null).map(() => ({ itemId: '', count: 0 })));
        addMsg('Wyczyszczono ekwipunek.', '#ffaa00');
        break;

      case 'kill':
        setStats(s => ({ ...s, health: 0 }));
        soundMgrRef.current.playHurt();
        addMsg('Steve poległ.', '#ff5555');
        setTimeout(() => {
          if (physicsRef.current) {
            physicsRef.current.position.set(0, 32, 0);
            physicsRef.current.velocity.set(0, 0, 0);
          }
          setStats(s => ({ ...s, health: 20, hunger: 20 }));
        }, 1500);
        break;

      case 'spawn':
        if (args[0] === 'mob' && entityMgrRef.current && physicsRef.current) {
          const mobType = (args[1] || 'pig') as any;
          const pos = physicsRef.current.position;
          entityMgrRef.current.spawnMob(mobType, pos.x + 2, pos.y, pos.z + 2);
          addMsg(`Zrespiono stwora: ${mobType}`, '#55ff55');
        }
        break;

      default:
        addMsg(`Nieznana komenda: /${cmd}. Wpisz /help po pomoc.`, '#ff5555');
        break;
    }
  }, [addItemToInventory]);

  // Main Three.js Setup & Game Loop
  useEffect(() => {
    if (!mountRef.current) return;
    const container = mountRef.current;

    // 1. Scene & Camera
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(settings.fov, window.innerWidth / window.innerHeight, 0.05, 500);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    renderer.toneMapping = THREE.LinearToneMapping;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // 2. Lighting & Sky
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);
    ambientLightRef.current = ambientLight;

    const sunLight = new THREE.DirectionalLight(0xffffff, 1.3);
    sunLight.position.set(50, 100, 50);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    scene.add(sunLight);
    sunLightRef.current = sunLight;

    // Sun & Moon 3D Voxel Meshes
    const sunGeo = new THREE.PlaneGeometry(24, 24);
    const sunMat = new THREE.MeshBasicMaterial({ color: 0xffffea, side: THREE.DoubleSide });
    const sunMesh = new THREE.Mesh(sunGeo, sunMat);
    scene.add(sunMesh);
    sunMeshRef.current = sunMesh;

    const moonGeo = new THREE.PlaneGeometry(18, 18);
    const moonMat = new THREE.MeshBasicMaterial({ color: 0xddddff, side: THREE.DoubleSide });
    const moonMesh = new THREE.Mesh(moonGeo, moonMat);
    scene.add(moonMesh);
    moonMeshRef.current = moonMesh;

    // Fog
    scene.fog = new THREE.FogExp2(0x78a7ff, 0.015);

    // 3. Engine managers
    const world = new WorldManager(scene, settings.seed);
    worldRef.current = world;

    const physics = new PhysicsController(world);
    world.getOrCreateChunk(0, 0);
    let spawnY = 28;
    for (let sy = 55; sy >= 0; sy--) {
      const b = world.getBlock(0, sy, 0);
      if (b !== BlockType.AIR && b !== BlockType.WATER) {
        spawnY = sy + 1;
        break;
      }
    }
    physics.position.set(0, spawnY + 0.5, 0);
    physicsRef.current = physics;

    const entityMgr = new EntityManager(scene, world);
    entityMgrRef.current = entityMgr;

    // Spawn starting mobs at terrain surface
    entityMgr.spawnMob('pig', 4, spawnY, 4);
    entityMgr.spawnMob('sheep', -5, spawnY, 3);
    entityMgr.spawnMob('pig', 2, spawnY, -6);
    entityMgr.spawnMob('zombie', 12, spawnY, 12);

    // 4. Highlight wireframe box for targeted block
    const boxGeo = new THREE.BoxGeometry(1.005, 1.005, 1.005);
    const wireGeo = new THREE.EdgesGeometry(boxGeo);
    const wireMat = new THREE.LineBasicMaterial({ color: 0x000000, linewidth: 2 });
    const highlightBox = new THREE.LineSegments(wireGeo, wireMat);
    highlightBox.visible = false;
    scene.add(highlightBox);
    highlightBoxRef.current = highlightBox;

    // 5. Break Crack Overlay mesh
    const crackGeo = new THREE.BoxGeometry(1.008, 1.008, 1.008);
    const crackMat = new THREE.MeshBasicMaterial({
      transparent: true,
      alphaTest: 0.1,
      depthTest: true,
      polygonOffset: true,
      polygonOffsetFactor: -1,
    });
    const breakOverlay = new THREE.Mesh(crackGeo, crackMat);
    breakOverlay.visible = false;
    scene.add(breakOverlay);
    breakOverlayRef.current = breakOverlay;

    // Start ambient music
    soundMgrRef.current.startAmbientMusic();

    // 6. Handle Window Resize
    const handleResize = () => {
      if (!cameraRef.current || !rendererRef.current) return;
      cameraRef.current.aspect = window.innerWidth / window.innerHeight;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    // 7. Pointer Lock & Mouse Listeners
    const onPointerLockChange = () => {
      const isLocked = document.pointerLockElement === renderer.domElement;
      isLockedRef.current = isLocked;
      if (!isLocked && !isInventoryOpen && !isChatOpen) {
        setIsPauseMenuOpen(true);
      }
    };
    document.addEventListener('pointerlockchange', onPointerLockChange);

    const onMouseMove = (e: MouseEvent) => {
      if (!isLockedRef.current) return;
      const sens = settings.mouseSensitivity;
      yawRef.current -= e.movementX * sens;
      pitchRef.current -= e.movementY * sens;
      pitchRef.current = Math.max(-Math.PI / 2 + 0.05, Math.min(Math.PI / 2 - 0.05, pitchRef.current));
    };
    window.addEventListener('mousemove', onMouseMove);

    // 8. Key Listeners
    const onKeyDown = (e: KeyboardEvent) => {
      if (isChatOpen) return;

      if (e.code === 'KeyE') {
        e.preventDefault();
        if (isInventoryOpen) {
          setIsInventoryOpen(false);
          setIsCraftingTableOpen(false);
          renderer.domElement.requestPointerLock();
        } else {
          document.exitPointerLock?.();
          setIsInventoryOpen(true);
          setIsCraftingTableOpen(false);
        }
        return;
      }

      if (e.code === 'KeyT' || e.key === '/') {
        e.preventDefault();
        document.exitPointerLock?.();
        setIsChatOpen(true);
        return;
      }

      if (e.code === 'F3') {
        e.preventDefault();
        setSettings(s => ({ ...s, showF3: !s.showF3 }));
        return;
      }

      if (e.code === 'KeyF' && stats.gameMode === 'creative') {
        e.preventDefault();
        setStats(s => {
          const nextFly = !s.isFlying;
          if (physicsRef.current) physicsRef.current.isFlying = nextFly;
          return { ...s, isFlying: nextFly };
        });
        return;
      }

      if (e.code === 'Escape') {
        if (isInventoryOpen) {
          setIsInventoryOpen(false);
          setIsCraftingTableOpen(false);
          renderer.domElement.requestPointerLock();
          return;
        }
        if (isChatOpen) {
          setIsChatOpen(false);
          renderer.domElement.requestPointerLock();
          return;
        }
        setIsPauseMenuOpen(prev => {
          if (!prev) document.exitPointerLock?.();
          else renderer.domElement.requestPointerLock();
          return !prev;
        });
        return;
      }

      // Hotbar 1-9
      if (e.key >= '1' && e.key <= '9') {
        const slotIdx = parseInt(e.key) - 1;
        setStats(s => ({ ...s, selectedHotbarIndex: slotIdx }));
        return;
      }

      keysRef.current[e.code] = true;
    };

    const onKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.code] = false;
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    // Mouse Wheel to cycle hotbar
    const onWheel = (e: WheelEvent) => {
      if (!isLockedRef.current) return;
      setStats(s => {
        const dir = Math.sign(e.deltaY);
        const nextIdx = (s.selectedHotbarIndex + dir + 9) % 9;
        return { ...s, selectedHotbarIndex: nextIdx };
      });
    };
    window.addEventListener('wheel', onWheel, { passive: true });

    // Mouse Down (Mining / Attack / Placement)
    const onMouseDown = (e: MouseEvent) => {
      if (!isLockedRef.current) {
        renderer.domElement.requestPointerLock();
        return;
      }

      triggerSwing();

      if (e.button === 0) {
        // Left click: start mining or attack mob
        isMouseDownRef.current = true;

        // Check if ray hits mob first!
        const eyePos = physicsRef.current!.getEyePosition();
        const lookDir = new THREE.Vector3(
          -Math.sin(yawRef.current) * Math.cos(pitchRef.current),
          Math.sin(pitchRef.current),
          -Math.cos(yawRef.current) * Math.cos(pitchRef.current)
        ).normalize();

        let hitMobId: string | null = null;
        for (const mob of entityMgrRef.current!.mobs) {
          const mobCenter = new THREE.Vector3(mob.x, mob.y + 0.6, mob.z);
          const toMob = mobCenter.clone().sub(eyePos);
          const dist = toMob.length();
          if (dist < 3.8) {
            const angle = lookDir.angleTo(toMob.normalize());
            if (angle < 0.35) {
              hitMobId = mob.id;
              break;
            }
          }
        }

        if (hitMobId) {
          // Attack mob!
          const activeItem = hotbar[stats.selectedHotbarIndex]?.itemId;
          const itemDef = activeItem ? ITEMS[activeItem] : null;
          const dmg = itemDef?.attackDamage || 1.5;
          entityMgrRef.current!.damageMob(hitMobId, dmg);
          return;
        }
      } else if (e.button === 2) {
        // Right click: Place block, activate TNT, open crafting table, or eat food
        const eyePos = physicsRef.current!.getEyePosition();
        const lookDir = new THREE.Vector3(
          -Math.sin(yawRef.current) * Math.cos(pitchRef.current),
          Math.sin(pitchRef.current),
          -Math.cos(yawRef.current) * Math.cos(pitchRef.current)
        ).normalize();

        const hit = worldRef.current!.raycast(eyePos, lookDir, 5.5);
        const activeSlot = hotbar[stats.selectedHotbarIndex];
        const activeItemDef = activeSlot?.itemId ? ITEMS[activeSlot.itemId] : null;

        // Eat food if hungry in survival
        if (activeItemDef?.foodRestore && stats.hunger < 20) {
          soundMgrRef.current.playBreak('grass');
          setStats(s => ({
            ...s,
            hunger: Math.min(20, s.hunger + activeItemDef.foodRestore!),
            health: Math.min(20, s.health + 2),
          }));
          if (stats.gameMode === 'survival') {
            setHotbar(hb => {
              const updated = [...hb];
              if (updated[stats.selectedHotbarIndex].count > 1) {
                updated[stats.selectedHotbarIndex].count -= 1;
              } else {
                updated[stats.selectedHotbarIndex] = { itemId: '', count: 0 };
              }
              return updated;
            });
          }
          return;
        }

        if (hit && hit.hit) {
          // If clicked block is Crafting Table -> open 3x3 GUI!
          if (hit.block === BlockType.CRAFTING_TABLE) {
            document.exitPointerLock?.();
            setIsInventoryOpen(true);
            setIsCraftingTableOpen(true);
            return;
          }

          // If clicked block is TNT -> trigger explosion fuse!
          if (hit.block === BlockType.TNT) {
            worldRef.current!.setBlock(hit.x, hit.y, hit.z, BlockType.AIR);
            soundMgrRef.current.playFuse();

            // Spawn flashing TNT entity or fuse timer
            setTimeout(() => {
              soundMgrRef.current.playExplosion();
              entityMgrRef.current!.spawnBlockBreakParticles(hit.x, hit.y, hit.z, 0xff2200, 40);

              // Blast radius blocks destruction
              const rad = 3;
              for (let bx = -rad; bx <= rad; bx++) {
                for (let by = -rad; by <= rad; by++) {
                  for (let bz = -rad; bz <= rad; bz++) {
                    if (bx * bx + by * by + bz * bz <= rad * rad) {
                      const tx = hit.x + bx;
                      const ty = hit.y + by;
                      const tz = hit.z + bz;
                      const b = worldRef.current!.getBlock(tx, ty, tz);
                      if (b !== BlockType.AIR && b !== BlockType.BEDROCK && b !== BlockType.WATER) {
                        const bDef = BLOCK_DEFS[b];
                        if (Math.random() < 0.6 && bDef.dropItem) {
                          entityMgrRef.current!.spawnDroppedItem(bDef.dropItem, 1, tx + 0.5, ty + 0.5, tz + 0.5);
                        }
                        worldRef.current!.setBlock(tx, ty, tz, BlockType.AIR);
                      }
                    }
                  }
                }
              }

              // Knockback player if near
              if (physicsRef.current) {
                const distToBlast = physicsRef.current.position.distanceTo(new THREE.Vector3(hit.x, hit.y, hit.z));
                if (distToBlast < 6.0) {
                  const push = physicsRef.current.position.clone().sub(new THREE.Vector3(hit.x, hit.y, hit.z)).normalize().multiplyScalar(12.0);
                  physicsRef.current.velocity.add(push);
                  soundMgrRef.current.playHurt();
                  setStats(s => ({ ...s, health: Math.max(1, s.health - Math.round(12 - distToBlast * 1.5)) }));
                }
              }
            }, 2200);

            return;
          }

          // Place Block
          if (activeItemDef?.isBlock && activeItemDef.blockType !== undefined) {
            const px = hit.placeX;
            const py = hit.placeY;
            const pz = hit.placeZ;

            // Check bounding box intersection with player
            const aabb = physicsRef.current!.getAABB();
            const intersectsPlayer = (
              px + 1 > aabb.minX && px < aabb.maxX &&
              py + 1 > aabb.minY && py < aabb.maxY &&
              pz + 1 > aabb.minZ && pz < aabb.maxZ
            );

            if (!intersectsPlayer) {
              const bDef = BLOCK_DEFS[activeItemDef.blockType];
              worldRef.current!.setBlock(px, py, pz, activeItemDef.blockType);
              soundMgrRef.current.playPlace(bDef.sound);

              // Decrement stack in survival
              if (stats.gameMode === 'survival') {
                setHotbar(hb => {
                  const updated = [...hb];
                  if (updated[stats.selectedHotbarIndex].count > 1) {
                    updated[stats.selectedHotbarIndex].count -= 1;
                  } else {
                    updated[stats.selectedHotbarIndex] = { itemId: '', count: 0 };
                  }
                  return updated;
                });
              }
            }
          }
        }
      }
    };

    const onMouseUp = (e: MouseEvent) => {
      if (e.button === 0) {
        isMouseDownRef.current = false;
        miningTimeRef.current = 0;
        miningTargetRef.current = null;
        if (breakOverlayRef.current) {
          breakOverlayRef.current.visible = false;
        }
      }
    };

    window.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);

    // 9. Main Game Loop
    let lastTime = performance.now();
    let frameCount = 0;
    let fpsTimer = 0;
    let animationFrameId: number;

    const gameLoop = (now: number) => {
      animationFrameId = requestAnimationFrame(gameLoop);
      const delta = Math.min((now - lastTime) / 1000, 0.1);
      lastTime = now;

      frameCount++;
      fpsTimer += delta;
      if (fpsTimer >= 1.0) {
        setFps(frameCount);
        frameCount = 0;
        fpsTimer = 0;

        const px = physics.position.x;
        const pz = physics.position.z;
        const bTemp = Math.sin(px * 0.005 + 100);
        const bMoist = Math.cos(pz * 0.005 - 100);
        if (bTemp > 0.3 && bMoist < -0.3) setCurrentBiome('desert');
        else if (bTemp < -0.4) setCurrentBiome('snowy_plains');
        else if (bMoist > 0.2) setCurrentBiome('forest');
        else setCurrentBiome('plains');
      }

      // Update time of day
      setSettings(s => {
        const nextTime = (s.timeOfDay + delta * 20 * s.timeSpeed) % 24000;

        // Dynamic Sky & Ambient Lighting
        const dayProgress = nextTime / 24000;
        const sunAngle = dayProgress * Math.PI * 2 - Math.PI / 2;
        const sunDist = 120;

        if (sunLightRef.current && sunMeshRef.current && moonMeshRef.current) {
          const sunX = Math.cos(sunAngle) * sunDist;
          const sunY = Math.sin(sunAngle) * sunDist;
          sunLightRef.current.position.set(sunX, sunY, 40);

          sunMeshRef.current.position.set(physics.position.x + sunX, physics.position.y + sunY, physics.position.z + 40);
          sunMeshRef.current.lookAt(physics.position);

          moonMeshRef.current.position.set(physics.position.x - sunX, physics.position.y - sunY, physics.position.z - 40);
          moonMeshRef.current.lookAt(physics.position);

          // Sunlight Intensity & Sky Color Interpolation
          const isSunUp = sunY > 0;
          const sunFactor = Math.max(0, Math.sin(sunAngle));
          sunLightRef.current.intensity = sunFactor * 1.4;

          const daySky = new THREE.Color(0x78a7ff);
          const sunsetSky = new THREE.Color(0xd96b38);
          const nightSky = new THREE.Color(0x0c1124);

          let currentSky = daySky;
          if (sunY < 15 && sunY > -15) {
            currentSky = sunsetSky;
          } else if (!isSunUp) {
            currentSky = nightSky;
          }

          if (sceneRef.current) {
            sceneRef.current.background = currentSky;
            if (sceneRef.current.fog) {
              sceneRef.current.fog.color = currentSky;
            }
          }

          if (ambientLightRef.current) {
            ambientLightRef.current.intensity = isSunUp ? 0.6 + sunFactor * 0.3 : 0.25;
            ambientLightRef.current.color = isSunUp ? new THREE.Color(0xffffff) : new THREE.Color(0x334466);
          }
        }

        return { ...s, timeOfDay: nextTime };
      });

      // Update Player Physics
      const forward = (keysRef.current['KeyW'] ? 1 : 0) - (keysRef.current['KeyS'] ? 1 : 0);
      const strafe = (keysRef.current['KeyD'] ? 1 : 0) - (keysRef.current['KeyA'] ? 1 : 0);
      const jump = !!keysRef.current['Space'];
      const sneak = !!keysRef.current['ShiftLeft'];
      const sprint = !!keysRef.current['ControlLeft'];

      physics.update(delta, { forward, strafe, jump, sneak, sprint }, yawRef.current);

      const moving = forward !== 0 || strafe !== 0;
      setIsWalking(moving);

      // Footstep audio on ground
      footstepTimerRef.current += delta;
      if (moving && physics.onGround && !physics.isFlying) {
        const stepInterval = sprint ? 0.28 : 0.42;
        if (footstepTimerRef.current > stepInterval) {
          const underBlock = world.getBlock(
            Math.floor(physics.position.x),
            Math.floor(physics.position.y - 0.2),
            Math.floor(physics.position.z)
          );
          const bDef = BLOCK_DEFS[underBlock];
          soundMgrRef.current.playStep(bDef ? bDef.sound : 'grass');
          footstepTimerRef.current = 0;
        }
      }

      // Fall damage check
      if (physics.onGround && prevVyRef.current < -15.0 && stats.gameMode === 'survival') {
        const fallDmg = Math.min(20, Math.floor((-prevVyRef.current - 14) * 1.5));
        if (fallDmg > 0) {
          soundMgrRef.current.playHurt();
          setStats(s => ({ ...s, health: Math.max(0, s.health - fallDmg) }));
        }
      }
      prevVyRef.current = physics.velocity.y;

      // Sync underwater status
      if (stats.isUnderwater !== physics.inWater) {
        setStats(s => ({ ...s, isUnderwater: physics.inWater }));
        if (physics.inWater) soundMgrRef.current.playSplash();
      }

      // Ambient mob sounds periodically
      mobSoundTimerRef.current += delta;
      if (mobSoundTimerRef.current > 6.0) {
        mobSoundTimerRef.current = 0;
        if (Math.random() < 0.45 && entityMgr.mobs.length > 0) {
          const randomMob = entityMgr.mobs[Math.floor(Math.random() * entityMgr.mobs.length)];
          if (randomMob.type === 'pig') soundMgrRef.current.playPig();
          else if (randomMob.type === 'zombie') soundMgrRef.current.playZombie();
        }
      }

      // Camera sync
      const eyePos = physics.getEyePosition();
      camera.position.copy(eyePos);
      camera.rotation.set(0, 0, 0);
      camera.rotation.y = yawRef.current;
      camera.rotation.x = pitchRef.current;

      // Update Chunks around player
      world.update(physics.position.x, physics.position.z, settings.renderDistance);

      // Raycast targeting for block highlights & mining
      const lookDir = new THREE.Vector3(
        -Math.sin(yawRef.current) * Math.cos(pitchRef.current),
        Math.sin(pitchRef.current),
        -Math.cos(yawRef.current) * Math.cos(pitchRef.current)
      ).normalize();

      const hit = world.raycast(eyePos, lookDir, 5.5);
      setTargetBlock(hit);

      if (hit && hit.hit) {
        // Position highlight box
        if (highlightBoxRef.current) {
          highlightBoxRef.current.position.set(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
          highlightBoxRef.current.visible = true;
        }

        // Mining Mechanics
        if (isMouseDownRef.current) {
          triggerSwing();
          const target = miningTargetRef.current;

          // Check if targeting same block
          if (!target || target.x !== hit.x || target.y !== hit.y || target.z !== hit.z) {
            miningTargetRef.current = { x: hit.x, y: hit.y, z: hit.z, block: hit.block };
            miningTimeRef.current = 0;
          }

          const bDef = BLOCK_DEFS[hit.block];

          // Compute tool efficiency
          const activeSlot = hotbar[stats.selectedHotbarIndex];
          const activeItemDef = activeSlot?.itemId ? ITEMS[activeSlot.itemId] : null;
          let speedMult = 1.0;
          if (activeItemDef && activeItemDef.toolType === bDef.tool) {
            speedMult = activeItemDef.miningSpeedMultiplier || 2.0;
          }

          // Hardness calculation
          const requiredTime = stats.gameMode === 'creative' ? 0.05 : Math.max(0.1, (bDef.hardness / speedMult) * 1.5);
          miningTimeRef.current += delta;

          // Hit sound & particles periodically
          if (now - lastHitSoundTimeRef.current > 180) {
            soundMgrRef.current.playHit(bDef.sound);
            entityMgr.spawnBlockBreakParticles(hit.x, hit.y, hit.z, 0x8b8b8b, 4);
            lastHitSoundTimeRef.current = now;
          }

          // Break Crack Overlay
          const breakStage = Math.min(9, Math.floor((miningTimeRef.current / requiredTime) * 10));
          if (breakOverlayRef.current) {
            breakOverlayRef.current.position.set(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
            (breakOverlayRef.current.material as THREE.MeshBasicMaterial).map = textureMgrRef.current.crackTextures[breakStage];
            (breakOverlayRef.current.material as THREE.MeshBasicMaterial).needsUpdate = true;
            breakOverlayRef.current.visible = true;
          }

          // Block Finished Breaking!
          if (miningTimeRef.current >= requiredTime && bDef.hardness >= 0) {
            world.setBlock(hit.x, hit.y, hit.z, BlockType.AIR);
            soundMgrRef.current.playBreak(bDef.sound);
            entityMgr.spawnBlockBreakParticles(hit.x, hit.y, hit.z, 0x866043, 24);

            // Spawn dropped item in survival mode
            if (stats.gameMode === 'survival' && bDef.dropItem) {
              entityMgr.spawnDroppedItem(bDef.dropItem, bDef.dropCount || 1, hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
            }

            miningTimeRef.current = 0;
            miningTargetRef.current = null;
            if (breakOverlayRef.current) {
              breakOverlayRef.current.visible = false;
            }
          }
        } else {
          miningTimeRef.current = 0;
          if (breakOverlayRef.current) {
            breakOverlayRef.current.visible = false;
          }
        }
      } else {
        if (highlightBoxRef.current) highlightBoxRef.current.visible = false;
        if (breakOverlayRef.current) breakOverlayRef.current.visible = false;
        miningTimeRef.current = 0;
      }

      // Update Entities & Item Pickups
      entityMgr.update(delta, physics.position, (itemId, count) => {
        addItemToInventory(itemId, count);
      });

      // Render
      renderer.render(scene, camera);
    };

    animationFrameId = requestAnimationFrame(gameLoop);

    // Cleanup
    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      document.removeEventListener('pointerlockchange', onPointerLockChange);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('wheel', onWheel);
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      soundMgrRef.current.stopAmbientMusic();
      if (rendererRef.current?.domElement) {
        container.removeChild(rendererRef.current.domElement);
      }
    };
  }, []);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-black select-none font-silkscreen">
      {/* Three.js Canvas Container */}
      <div ref={mountRef} className="w-full h-full cursor-crosshair" />

      {/* Underwater Vision Filter */}
      {stats.isUnderwater && (
        <div className="fixed inset-0 z-10 pointer-events-none bg-blue-700/30 backdrop-blur-[0.5px] transition-opacity duration-300" />
      )}

      {/* Critical Health Damage Vignette */}
      {stats.health <= 6 && stats.health > 0 && stats.gameMode === 'survival' && (
        <div className="fixed inset-0 z-10 pointer-events-none shadow-[inset_0_0_120px_rgba(220,20,20,0.6)] animate-pulse" />
      )}

      {/* Held Item & Animated Hand Overlay */}
      <HeldItemArm
        heldSlot={hotbar[stats.selectedHotbarIndex]}
        isSwinging={isSwinging}
        isWalking={isWalking}
      />

      {/* Main HUD: Crosshair, Health, Food, Hotbar */}
      <HUD
        stats={stats}
        hotbar={hotbar}
        activeSlotIndex={stats.selectedHotbarIndex}
        onSelectSlot={idx => setStats(s => ({ ...s, selectedHotbarIndex: idx }))}
        crosshairBlockName={targetBlock ? BLOCK_DEFS[targetBlock.block]?.namePl : undefined}
      />

      {/* F3 Diagnostic Screen */}
      <DebugF3
        show={settings.showF3}
        fps={fps}
        playerPos={physicsRef.current ? physicsRef.current.position : { x: 0, y: 0, z: 0 }}
        playerRot={{ yaw: yawRef.current, pitch: pitchRef.current }}
        timeOfDay={settings.timeOfDay}
        targetBlock={targetBlock}
        biome={currentBiome}
        mobCount={entityMgrRef.current ? entityMgrRef.current.mobs.length : 0}
        gameMode={stats.gameMode}
      />

      {/* Inventory & Crafting GUI */}
      <InventoryModal
        isOpen={isInventoryOpen}
        onClose={() => {
          setIsInventoryOpen(false);
          setIsCraftingTableOpen(false);
          rendererRef.current?.domElement.requestPointerLock();
        }}
        inventory={inventory}
        hotbar={hotbar}
        gameMode={stats.gameMode}
        isCraftingTableOpen={isCraftingTableOpen}
        onUpdateInventory={handleUpdateInventory}
      />

      {/* Pause & Settings Menu */}
      <PauseMenu
        isOpen={isPauseMenuOpen}
        onResume={() => {
          setIsPauseMenuOpen(false);
          rendererRef.current?.domElement.requestPointerLock();
        }}
        settings={settings}
        gameMode={stats.gameMode}
        onUpdateSettings={newSets => setSettings(s => ({ ...s, ...newSets }))}
        onToggleGameMode={() => {
          setStats(s => {
            const nextMode: GameMode = s.gameMode === 'survival' ? 'creative' : 'survival';
            if (physicsRef.current) {
              physicsRef.current.isFlying = nextMode === 'creative';
            }
            return { ...s, gameMode: nextMode, isFlying: nextMode === 'creative' };
          });
        }}
        onSaveWorld={handleSaveWorld}
        onLoadWorld={handleLoadWorld}
        onResetWorld={handleResetWorld}
      />

      {/* Chat & Commands Box */}
      <ChatBox
        isOpen={isChatOpen}
        onClose={() => {
          setIsChatOpen(false);
          rendererRef.current?.domElement.requestPointerLock();
        }}
        messages={chatMessages}
        onSendMessage={text => {
          setChatMessages(prev => [...prev, { id: Math.random().toString(), sender: 'Steve', text }]);
        }}
        onExecuteCommand={handleExecuteCommand}
        gameMode={stats.gameMode}
      />

      {/* Click-to-play start overlay when pointer lock is released */}
      {!isLockedRef.current && !isPauseMenuOpen && !isInventoryOpen && !isChatOpen && (
        <div
          onClick={() => rendererRef.current?.domElement.requestPointerLock()}
          className="fixed inset-0 z-30 flex flex-col items-center justify-center bg-black/60 backdrop-blur-xs cursor-pointer select-none"
        >
          <div className="mc-panel p-8 rounded-lg text-center max-w-lg shadow-2xl animate-fade-in border-4">
            <h1 className="font-pixel text-2xl text-yellow-300 mb-4 drop-shadow-[2px_2px_0px_#000]">
              MINECRAFT WEB 3D
            </h1>
            <p className="font-vt323 text-xl text-gray-200 mb-6 leading-relaxed">
              Realistyczna, płynna i w pełni interaktywna gra wokselowa w Twojej przeglądarce!
            </p>
            <div className="py-3 px-6 mc-button font-pixel text-sm text-white bg-green-600 hover:bg-green-500 rounded mb-4 cursor-pointer inline-block shadow-lg">
              KLIKNIJ, ABY ZAGRAĆ
            </div>
            <p className="font-vt323 text-base text-gray-300">
              Sterowanie: <strong>WASD</strong> do ruchu, <strong>Mysz</strong> do patrzenia, <strong>LPM</strong> do niszczenia, <strong>PPM</strong> do stawiania, <strong>E</strong> do ekwipunku.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
