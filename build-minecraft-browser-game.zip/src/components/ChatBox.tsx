import React, { useState, useEffect, useRef } from 'react';
import { GameMode } from '../types/game';

export interface ChatMessage {
  id: string;
  sender?: string;
  text: string;
  color?: string;
}

interface ChatBoxProps {
  isOpen: boolean;
  onClose: () => void;
  messages: ChatMessage[];
  onSendMessage: (msg: string) => void;
  onExecuteCommand: (cmd: string, args: string[]) => void;
  gameMode: GameMode;
}

export const ChatBox: React.FC<ChatBoxProps> = ({
  isOpen,
  onClose,
  messages,
  onSendMessage,
  onExecuteCommand,
}) => {
  const [inputVal, setInputVal] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = inputVal.trim();
    if (!trimmed) {
      onClose();
      return;
    }

    if (trimmed.startsWith('/')) {
      const parts = trimmed.slice(1).split(' ');
      const cmd = parts[0].toLowerCase();
      const args = parts.slice(1);
      onExecuteCommand(cmd, args);
    } else {
      onSendMessage(trimmed);
    }

    setInputVal('');
    onClose();
  };

  return (
    <div className={`fixed bottom-14 left-4 z-40 max-w-lg w-full transition-opacity duration-200 pointer-events-none ${isOpen ? 'pointer-events-auto opacity-100' : 'opacity-85'}`}>
      {/* Message history */}
      <div
        ref={scrollRef}
        className="max-h-56 overflow-y-auto space-y-1 p-2 rounded-t font-vt323 text-lg leading-snug drop-shadow-[1px_1px_0px_#000]"
        style={{ backgroundColor: isOpen ? 'rgba(0,0,0,0.65)' : 'rgba(0,0,0,0.3)' }}
      >
        {messages.slice(-20).map(msg => (
          <div key={msg.id} style={{ color: msg.color || '#ffffff' }}>
            {msg.sender ? (
              <span>
                <span className="text-yellow-300">&lt;{msg.sender}&gt;</span> {msg.text}
              </span>
            ) : (
              <span>{msg.text}</span>
            )}
          </div>
        ))}
      </div>

      {/* Input row */}
      {isOpen && (
        <form onSubmit={handleSubmit} className="flex bg-black/80 p-1 rounded-b border border-white/20">
          <input
            ref={inputRef}
            type="text"
            value={inputVal}
            onChange={e => setInputVal(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Escape') {
                e.stopPropagation();
                onClose();
              }
            }}
            placeholder="Wpisz wiadomość lub /polecenie (np. /help, /gamemode c, /time set day, /give diamond 64)..."
            className="flex-1 bg-transparent px-2 py-1 font-vt323 text-xl text-white focus:outline-hidden placeholder:text-gray-500"
          />
        </form>
      )}
    </div>
  );
};
