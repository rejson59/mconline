import React, { useEffect, useState } from 'react';
import { PlayerStats, InventorySlot } from '../types/game';
import { ITEMS, BLOCK_DEFS } from '../engine/blocks';
import { TextureManager } from '../engine/textures';

interface HUDProps {
  stats: PlayerStats;
  hotbar: InventorySlot[];
  activeSlotIndex: number;
  onSelectSlot: (idx: number) => void;
  crosshairBlockName?: string;
}

export const HUD: React.FC<HUDProps> = ({
  stats,
  hotbar,
  activeSlotIndex,
  onSelectSlot,
  crosshairBlockName,
}) => {
  const [activeItemToast, setActiveItemToast] = useState<string>('');
  const textureMgr = TextureManager.getInstance();

  const currentSlot = hotbar[activeSlotIndex];
  const currentItem = currentSlot?.itemId ? ITEMS[currentSlot.itemId] : null;

  // Show item name for 2 seconds on hotbar change
  useEffect(() => {
    if (currentItem) {
      setActiveItemToast(currentItem.namePl);
      const timer = setTimeout(() => setActiveItemToast(''), 2200);
      return () => clearTimeout(timer);
    } else {
      setActiveItemToast('');
    }
  }, [activeSlotIndex, currentSlot?.itemId]);

  // Render Hearts (20 HP = 10 hearts)
  const renderHearts = () => {
    const hearts = [];
    const maxHearts = Math.ceil(stats.maxHealth / 2);
    for (let i = 0; i < maxHearts; i++) {
      const heartHp = (i + 1) * 2;
      let heartType = 'empty';
      if (stats.health >= heartHp) {
        heartType = 'full';
      } else if (stats.health >= heartHp - 1) {
        heartType = 'half';
      }

      hearts.push(
        <div key={i} className="relative w-4 h-4 inline-block">
          {heartType === 'full' && (
            <svg viewBox="0 0 16 16" className="w-4 h-4 filter drop-shadow-[1px_1px_0px_#000]">
              <path fill="#e02020" stroke="#000" strokeWidth="1" d="M8,14 C8,14 1,9 1,4.5 C1,2 3,1 5,1 C6.5,1 7.5,2 8,3 C8.5,2 9.5,1 11,1 C13,1 15,2 15,4.5 C15,9 8,14 8,14 Z" />
              <path fill="#ff7f7f" d="M3.5,3 C2.5,3 2,3.5 2,4.5 C2,5.5 3,7 5,9 L5.5,8 C4,6 3.5,4.5 3.5,3 Z" />
            </svg>
          )}
          {heartType === 'half' && (
            <svg viewBox="0 0 16 16" className="w-4 h-4 filter drop-shadow-[1px_1px_0px_#000]">
              <path fill="#222" stroke="#000" strokeWidth="1" d="M8,14 C8,14 1,9 1,4.5 C1,2 3,1 5,1 C6.5,1 7.5,2 8,3 C8.5,2 9.5,1 11,1 C13,1 15,2 15,4.5 C15,9 8,14 8,14 Z" />
              <path fill="#e02020" d="M8,14 C8,14 1,9 1,4.5 C1,2 3,1 5,1 C6.5,1 7.5,2 8,3 L8,14 Z" />
              <path fill="#ff7f7f" d="M3.5,3 C2.5,3 2,3.5 2,4.5 C2,5.5 3,7 5,9 L5.5,8 C4,6 3.5,4.5 3.5,3 Z" />
            </svg>
          )}
          {heartType === 'empty' && (
            <svg viewBox="0 0 16 16" className="w-4 h-4 opacity-50 filter drop-shadow-[1px_1px_0px_#000]">
              <path fill="#2a2a2a" stroke="#000" strokeWidth="1" d="M8,14 C8,14 1,9 1,4.5 C1,2 3,1 5,1 C6.5,1 7.5,2 8,3 C8.5,2 9.5,1 11,1 C13,1 15,2 15,4.5 C15,9 8,14 8,14 Z" />
            </svg>
          )}
        </div>
      );
    }
    return hearts;
  };

  // Render Hunger (Drumsticks)
  const renderHunger = () => {
    const drumsticks = [];
    const maxDrumsticks = Math.ceil(stats.maxHunger / 2);
    for (let i = 0; i < maxDrumsticks; i++) {
      const hungerVal = (i + 1) * 2;
      const isFull = stats.hunger >= hungerVal;
      const isHalf = stats.hunger >= hungerVal - 1 && !isFull;

      drumsticks.push(
        <div key={i} className="relative w-4 h-4 inline-block">
          {isFull ? (
            <svg viewBox="0 0 16 16" className="w-4 h-4 filter drop-shadow-[1px_1px_0px_#000]">
              <path fill="#854d19" stroke="#000" strokeWidth="1" d="M12,2 C10,2 8,4 8,7 C8,9 9,10 9,12 L7,14 L5,12 C4,13 4,14 5,15 C6,16 7,16 8,15 L10,13 C11,13 13,12 14,10 C15,8 15,5 14,3 C13.5,2.3 12.8,2 12,2 Z" />
              <path fill="#d9822b" d="M11,4 C10,5 9,6 9,8 C9.5,9 11,9 12,8 C13,7 13.5,5 13,4 Z" />
            </svg>
          ) : isHalf ? (
            <svg viewBox="0 0 16 16" className="w-4 h-4 filter drop-shadow-[1px_1px_0px_#000]">
              <path fill="#222" stroke="#000" strokeWidth="1" d="M12,2 C10,2 8,4 8,7 C8,9 9,10 9,12 L7,14 L5,12 C4,13 4,14 5,15 C6,16 7,16 8,15 L10,13 C11,13 13,12 14,10 C15,8 15,5 14,3 C13.5,2.3 12.8,2 12,2 Z" />
              <path fill="#d9822b" d="M11,4 C10,5 9,6 9,8 C9.5,9 10,9 10,8 C10,7 11,5 11,4 Z" />
            </svg>
          ) : (
            <svg viewBox="0 0 16 16" className="w-4 h-4 opacity-40 filter drop-shadow-[1px_1px_0px_#000]">
              <path fill="#333" stroke="#000" strokeWidth="1" d="M12,2 C10,2 8,4 8,7 C8,9 9,10 9,12 L7,14 L5,12 C4,13 4,14 5,15 C6,16 7,16 8,15 L10,13 C11,13 13,12 14,10 C15,8 15,5 14,3 C13.5,2.3 12.8,2 12,2 Z" />
            </svg>
          )}
        </div>
      );
    }
    return drumsticks;
  };

  // Render Bubbles if underwater
  const renderAir = () => {
    if (!stats.isUnderwater && stats.air >= stats.maxAir) return null;
    const bubbles = [];
    const count = Math.ceil(stats.air / 2);
    for (let i = 0; i < 10; i++) {
      bubbles.push(
        <div key={i} className={`w-3.5 h-3.5 rounded-full border border-black ${i < count ? 'bg-cyan-300 shadow-[0_0_4px_#38bdf8]' : 'bg-transparent'}`} />
      );
    }
    return (
      <div className="flex gap-1 justify-end mb-1">
        {bubbles}
      </div>
    );
  };

  const getItemIcon = (slot: InventorySlot) => {
    if (!slot.itemId) return null;
    const def = ITEMS[slot.itemId];
    if (!def) return null;

    if (def.isBlock && def.blockType !== undefined) {
      const bDef = BLOCK_DEFS[def.blockType];
      const iconUrl = textureMgr.itemIcons[bDef.sideTexture] || textureMgr.itemIcons[bDef.topTexture];
      if (iconUrl) {
        return <img src={iconUrl} alt={def.namePl} className="w-8 h-8 pixelated pointer-events-none drop-shadow-[2px_2px_0px_rgba(0,0,0,0.5)]" />;
      }
    }

    const toolIcon = textureMgr.itemIcons[def.id];
    if (toolIcon) {
      return <img src={toolIcon} alt={def.namePl} className="w-8 h-8 pixelated pointer-events-none drop-shadow-[2px_2px_0px_rgba(0,0,0,0.5)]" />;
    }

    return (
      <div
        className="w-7 h-7 rounded-sm border border-black/40 flex items-center justify-center font-bold text-xs"
        style={{ backgroundColor: def.color || '#888' }}
      >
        {def.namePl.charAt(0)}
      </div>
    );
  };

  return (
    <div className="pointer-events-none absolute inset-0 z-20 flex flex-col justify-between">
      {/* Target Block Name (Minecraft style small subtitle) */}
      <div className="pt-4 text-center">
        {crosshairBlockName && (
          <span className="bg-black/60 backdrop-blur-xs px-3 py-1 rounded text-white text-xs font-pixel tracking-wider shadow">
            {crosshairBlockName}
          </span>
        )}
      </div>

      {/* Crosshair (+) */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none z-30">
        <div className="relative w-5 h-5 flex items-center justify-center">
          <div className="absolute w-4 h-[2px] bg-white/90 shadow-[0_0_2px_#000]" />
          <div className="absolute h-4 w-[2px] bg-white/90 shadow-[0_0_2px_#000]" />
        </div>
      </div>

      {/* Bottom Area: Stats & Hotbar */}
      <div className="flex flex-col items-center pb-3">
        {/* Item Name Toast */}
        {activeItemToast && (
          <div className="mb-2 text-white font-pixel text-sm drop-shadow-[2px_2px_0px_#000] tracking-wide animate-fade-in">
            {activeItemToast}
          </div>
        )}

        {/* Survival Status Bars (Health, Armor, Hunger, Air) */}
        {stats.gameMode === 'survival' && (
          <div className="w-[364px] mb-2 px-1 flex flex-col gap-1">
            {renderAir()}
            <div className="flex justify-between items-center w-full">
              {/* Hearts */}
              <div className="flex gap-0.5">{renderHearts()}</div>
              {/* Hunger */}
              <div className="flex gap-0.5 flex-row-reverse">{renderHunger()}</div>
            </div>
          </div>
        )}

        {/* Hotbar Container */}
        <div className="pointer-events-auto flex items-center bg-[#8b8b8b] p-1 rounded-sm border-2 border-t-white border-l-white border-b-[#373737] border-r-[#373737] shadow-[0_4px_16px_rgba(0,0,0,0.8)]">
          {hotbar.map((slot, index) => {
            const isSelected = index === activeSlotIndex;
            return (
              <div
                key={index}
                onClick={() => onSelectSlot(index)}
                className={`relative w-10 h-10 flex items-center justify-center cursor-pointer transition-transform ${
                  isSelected
                    ? 'border-3 border-white scale-105 z-10 bg-[#a0a0a0] shadow-inner'
                    : 'border-2 border-t-[#373737] border-l-[#373737] border-b-white border-r-white bg-[#8b8b8b] hover:bg-[#999]'
                }`}
              >
                {/* Slot Number 1-9 */}
                <span className="absolute top-0 left-0.5 text-[9px] text-white/50 font-pixel select-none pointer-events-none">
                  {index + 1}
                </span>

                {/* Item Icon */}
                {getItemIcon(slot)}

                {/* Stack Count */}
                {slot.count > 1 && (
                  <span className="absolute bottom-0.5 right-1 font-pixel text-[11px] text-white drop-shadow-[2px_2px_0px_#000] select-none pointer-events-none">
                    {slot.count}
                  </span>
                )}
              </div>
            );
          })}
        </div>

        {/* Game Mode Hint */}
        <div className="mt-1 flex items-center gap-3 text-[10px] text-white/70 font-vt323 tracking-wide">
          <span>Tryb: {stats.gameMode === 'survival' ? 'Przetrwanie (Survival)' : 'Kreatywny (Creative)'}</span>
          <span>•</span>
          <span>E: Ekwipunek</span>
          <span>•</span>
          <span>F3: Info</span>
          <span>•</span>
          <span>T: Chat</span>
          <span>•</span>
          <span>ESC: Menu</span>
        </div>
      </div>
    </div>
  );
};
