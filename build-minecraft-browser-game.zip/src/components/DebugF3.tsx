import React from 'react';
import { RaycastResult } from '../engine/world';
import { BLOCK_DEFS } from '../engine/blocks';

interface DebugF3Props {
  show: boolean;
  fps: number;
  playerPos: { x: number; y: number; z: number };
  playerRot: { yaw: number; pitch: number };
  timeOfDay: number;
  targetBlock: RaycastResult | null;
  biome: string;
  mobCount: number;
  gameMode: string;
}

export const DebugF3: React.FC<DebugF3Props> = ({
  show,
  fps,
  playerPos,
  playerRot,
  timeOfDay,
  targetBlock,
  biome,
  mobCount,
  gameMode,
}) => {
  if (!show) return null;

  // Compute facing direction
  const degYaw = ((playerRot.yaw * 180 / Math.PI) % 360 + 360) % 360;
  let facing = 'north (Towards negative Z)';
  if (degYaw >= 45 && degYaw < 135) facing = 'west (Towards negative X)';
  else if (degYaw >= 135 && degYaw < 225) facing = 'south (Towards positive Z)';
  else if (degYaw >= 225 && degYaw < 315) facing = 'east (Towards positive X)';

  // Format Minecraft in-game clock (0 = 06:00, 6000 = 12:00, 12000 = 18:00, 18000 = 00:00)
  const totalMinutes = Math.floor((timeOfDay / 24000) * 24 * 60 + 6 * 60) % (24 * 60);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  const timeFormatted = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
  const dayNumber = Math.floor(timeOfDay / 24000) + 1;

  const targetBlockDef = targetBlock ? BLOCK_DEFS[targetBlock.block] : null;

  return (
    <div className="pointer-events-none fixed inset-0 z-40 p-2 font-vt323 text-white text-base leading-tight select-none">
      {/* Top Left Stats */}
      <div className="bg-black/60 backdrop-blur-xs p-2 rounded-xs inline-block shadow-md">
        <div className="text-yellow-300 font-bold">Minecraft 1.20-web (Three.js WebGL Voxel Edition)</div>
        <div>FPS: <span className={fps < 30 ? 'text-red-400' : 'text-emerald-400'}>{fps}</span> ({Math.round(1000 / Math.max(1, fps))}ms)</div>
        <div className="text-gray-300">
          XYZ: {playerPos.x.toFixed(3)} / {playerPos.y.toFixed(3)} / {playerPos.z.toFixed(3)}
        </div>
        <div className="text-gray-300">
          Block: {Math.floor(playerPos.x)} {Math.floor(playerPos.y)} {Math.floor(playerPos.z)}
        </div>
        <div className="text-gray-300">
          Chunk: {Math.floor(playerPos.x / 16)} {Math.floor(playerPos.z / 16)} [sub {(Math.floor(playerPos.x) % 16 + 16) % 16}, {(Math.floor(playerPos.z) % 16 + 16) % 16}]
        </div>
        <div>
          Facing: <span className="text-cyan-300">{facing}</span>
        </div>
        <div>
          Biome: <span className="text-green-400">minecraft:{biome}</span>
        </div>
        <div>
          Czas: <span className="text-amber-300">{timeFormatted}</span> (Dzień {dayNumber}, Ticks: {Math.floor(timeOfDay % 24000)})
        </div>
        <div>
          Tryb gry: <span className="text-purple-300">{gameMode}</span> | Bytów: {mobCount}
        </div>
        <div className="text-gray-400 text-xs mt-1">
          Naciśnij [F3] aby ukryć menu diagnostyczne
        </div>
      </div>

      {/* Top Right Target Block Info */}
      {targetBlock && targetBlockDef && (
        <div className="fixed top-2 right-2 bg-black/60 backdrop-blur-xs p-2 rounded-xs inline-block shadow-md text-right">
          <div className="text-cyan-300 font-bold">Celowany Blok:</div>
          <div className="text-white text-lg">{targetBlockDef.namePl} ({targetBlockDef.name})</div>
          <div className="text-gray-300">Pozycja: {targetBlock.x}, {targetBlock.y}, {targetBlock.z}</div>
          <div className="text-gray-300">Twardość: {targetBlockDef.hardness < 0 ? 'Niezniszczalny' : targetBlockDef.hardness}</div>
          <div className="text-gray-300">Narzędzie: {targetBlockDef.tool}</div>
          <div className="text-emerald-300">Odległość: {targetBlock.distance.toFixed(2)}m</div>
        </div>
      )}
    </div>
  );
};
