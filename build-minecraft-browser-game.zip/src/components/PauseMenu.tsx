import React, { useState } from 'react';
import { WorldSettings, GameMode } from '../types/game';
import { Volume2, Eye, Sun, Save, Download, RotateCcw, HelpCircle, Gamepad2 } from 'lucide-react';

interface PauseMenuProps {
  isOpen: boolean;
  onResume: () => void;
  settings: WorldSettings;
  gameMode: GameMode;
  onUpdateSettings: (settings: Partial<WorldSettings>) => void;
  onToggleGameMode: () => void;
  onSaveWorld: () => void;
  onLoadWorld: () => void;
  onResetWorld: (newSeed: number) => void;
}

export const PauseMenu: React.FC<PauseMenuProps> = ({
  isOpen,
  onResume,
  settings,
  gameMode,
  onUpdateSettings,
  onToggleGameMode,
  onSaveWorld,
  onLoadWorld,
  onResetWorld,
}) => {
  const [showControlsHelp, setShowControlsHelp] = useState(false);
  const [seedInput, setSeedInput] = useState(settings.seed.toString());
  const [saveStatus, setSaveStatus] = useState<string>('');

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveWorld();
    setSaveStatus('Świat zapisany pomyślnie!');
    setTimeout(() => setSaveStatus(''), 2500);
  };

  const handleLoad = () => {
    onLoadWorld();
    setSaveStatus('Świat wczytany pomyślnie!');
    setTimeout(() => setSaveStatus(''), 2500);
  };

  const handleSeedSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseInt(seedInput) || Math.floor(Math.random() * 100000);
    onResetWorld(parsed);
    setSaveStatus(`Wygenerowano nowy świat z seedem: ${parsed}`);
    setTimeout(() => setSaveStatus(''), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs select-none">
      <div className="mc-panel p-6 rounded-md shadow-2xl max-w-lg w-full text-center relative border-3">
        {/* Title */}
        <h2 className="font-pixel text-xl text-[#222] mb-4 pb-2 border-b-2 border-[#555] tracking-wider">
          Menu Gry (Minecraft Web)
        </h2>

        {saveStatus && (
          <div className="mb-3 py-1.5 px-3 bg-emerald-600/90 text-white font-pixel text-xs rounded border border-emerald-400">
            {saveStatus}
          </div>
        )}

        {showControlsHelp ? (
          <div className="text-left bg-[#8b8b8b] p-4 rounded border-2 border-t-[#373737] border-l-[#373737] border-b-white border-r-white text-white mb-4 max-h-[360px] overflow-y-auto">
            <h3 className="font-pixel text-sm text-yellow-300 mb-3 flex items-center gap-2">
              <Gamepad2 size={16} /> Sterowanie w grze
            </h3>
            <ul className="space-y-1.5 font-vt323 text-lg leading-tight">
              <li><strong className="text-cyan-300">W, A, S, D</strong> - Chodzenie</li>
              <li><strong className="text-cyan-300">Mysz</strong> - Rozglądanie się (kliknij na ekran, aby zablokować kursor)</li>
              <li><strong className="text-cyan-300">Spacja</strong> - Skok / Wynurzenie w wodzie / Latanie w górę</li>
              <li><strong className="text-cyan-300">Lewy Shift</strong> - Kucanie (Sneak) / Latanie w dół</li>
              <li><strong className="text-cyan-300">Lewy Ctrl</strong> - Sprint (szybki bieg)</li>
              <li><strong className="text-cyan-300">LPM (Lewy Przycisk)</strong> - Niszczenie bloków / Atak potworów</li>
              <li><strong className="text-cyan-300">PPM (Prawy Przycisk)</strong> - Stawianie bloków / Użycie stołu / Detonacja TNT</li>
              <li><strong className="text-cyan-300">1 - 9 lub Kółko Myszy</strong> - Wybór slotu z paska narzędzi</li>
              <li><strong className="text-cyan-300">E</strong> - Ekwipunek i wytwarzanie</li>
              <li><strong className="text-cyan-300">F</strong> - Włącz/Wyłącz latanie (tryb kreatywny)</li>
              <li><strong className="text-cyan-300">F3</strong> - Ekran diagnostyczny (współrzędne, biom, FPS)</li>
              <li><strong className="text-cyan-300">T lub /</strong> - Chat i polecenia (/gamemode, /time, /give, /tp)</li>
              <li><strong className="text-cyan-300">ESC</strong> - Menu pauzy i ustawienia</li>
            </ul>
            <button
              onClick={() => setShowControlsHelp(false)}
              className="mt-4 w-full py-2 mc-button font-pixel text-xs"
            >
              Powrót do menu
            </button>
          </div>
        ) : (
          <div className="space-y-2.5">
            {/* Resume button */}
            <button
              onClick={onResume}
              className="w-full py-2.5 mc-button font-pixel text-xs text-white bg-green-700 hover:bg-green-600 cursor-pointer shadow-md"
            >
              Wróć do gry
            </button>

            {/* Quick Toggles: GameMode & Time */}
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={onToggleGameMode}
                className="py-2 mc-button font-pixel text-[11px] flex items-center justify-center gap-1.5 cursor-pointer"
              >
                Tryb: <span className="text-yellow-300">{gameMode === 'survival' ? 'Przetrwanie' : 'Kreatywny'}</span>
              </button>

              <button
                onClick={() => {
                  const times = [6000, 12000, 18000, 0]; // Day, Sunset, Night, Sunrise
                  const nextTime = times[(times.indexOf(settings.timeOfDay) + 1) % times.length];
                  onUpdateSettings({ timeOfDay: nextTime });
                }}
                className="py-2 mc-button font-pixel text-[11px] flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Sun size={14} /> Pora dnia
              </button>
            </div>

            {/* Render Distance & FOV sliders */}
            <div className="bg-[#8b8b8b] p-3 rounded border-2 border-t-[#373737] border-l-[#373737] border-b-white border-r-white text-left space-y-3">
              <div>
                <div className="flex justify-between font-pixel text-[10px] text-white mb-1">
                  <span className="flex items-center gap-1"><Eye size={12} /> Zasięg widzenia:</span>
                  <span className="text-yellow-300">{settings.renderDistance} chunków</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="6"
                  step="1"
                  value={settings.renderDistance}
                  onChange={e => onUpdateSettings({ renderDistance: parseInt(e.target.value) })}
                  className="w-full accent-yellow-400 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between font-pixel text-[10px] text-white mb-1">
                  <span>Pole widzenia (FOV):</span>
                  <span className="text-yellow-300">{settings.fov}°</span>
                </div>
                <input
                  type="range"
                  min="60"
                  max="95"
                  step="5"
                  value={settings.fov}
                  onChange={e => onUpdateSettings({ fov: parseInt(e.target.value) })}
                  className="w-full accent-yellow-400 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between font-pixel text-[10px] text-white mb-1">
                  <span className="flex items-center gap-1"><Volume2 size={12} /> Głośność dźwięków:</span>
                  <span className="text-yellow-300">{Math.round(settings.soundVolume * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={settings.soundVolume}
                  onChange={e => onUpdateSettings({ soundVolume: parseFloat(e.target.value) })}
                  className="w-full accent-yellow-400 cursor-pointer"
                />
              </div>
            </div>

            {/* Save & Load */}
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handleSave}
                className="py-2 mc-button font-pixel text-[11px] flex items-center justify-center gap-1 cursor-pointer"
              >
                <Save size={13} /> Zapisz świat
              </button>

              <button
                onClick={handleLoad}
                className="py-2 mc-button font-pixel text-[11px] flex items-center justify-center gap-1 cursor-pointer"
              >
                <Download size={13} /> Wczytaj zapis
              </button>
            </div>

            {/* Seed changer */}
            <form onSubmit={handleSeedSubmit} className="flex gap-2">
              <input
                type="text"
                placeholder="Ziarno świata (Seed)..."
                value={seedInput}
                onChange={e => setSeedInput(e.target.value)}
                className="bg-[#8b8b8b] border-2 border-t-[#373737] border-l-[#373737] border-b-white border-r-white px-2 py-1.5 font-pixel text-xs text-white focus:outline-hidden flex-1"
              />
              <button
                type="submit"
                className="px-3 py-1.5 mc-button font-pixel text-[10px] flex items-center gap-1 cursor-pointer whitespace-nowrap"
              >
                <RotateCcw size={12} /> Nowy Seed
              </button>
            </form>

            {/* Controls Help button */}
            <button
              onClick={() => setShowControlsHelp(true)}
              className="w-full py-2 mc-button font-pixel text-[11px] flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <HelpCircle size={14} /> Sterowanie i pomoc
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
