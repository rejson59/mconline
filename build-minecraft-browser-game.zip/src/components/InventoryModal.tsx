import React, { useState, useEffect } from 'react';
import { InventorySlot, GameMode } from '../types/game';
import { ITEMS, BLOCK_DEFS } from '../engine/blocks';
import { TextureManager } from '../engine/textures';
import { findCraftingMatch } from '../engine/crafting';
import { SoundManager } from '../engine/audio';
import { X, Search } from 'lucide-react';

interface InventoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  inventory: InventorySlot[]; // 27 slots (0-26)
  hotbar: InventorySlot[]; // 9 slots (0-8)
  gameMode: GameMode;
  isCraftingTableOpen: boolean;
  onUpdateInventory: (newInv: InventorySlot[], newHotbar: InventorySlot[]) => void;
}

export const InventoryModal: React.FC<InventoryModalProps> = ({
  isOpen,
  onClose,
  inventory,
  hotbar,
  gameMode,
  isCraftingTableOpen,
  onUpdateInventory,
}) => {
  const [activeTab, setActiveTab] = useState<'survival' | 'creative'>('survival');
  const [searchTerm, setSearchTerm] = useState('');
  const [heldItem, setHeldItem] = useState<{ itemId: string; count: number } | null>(null);
  const [hoveredItem, setHoveredItem] = useState<{ itemId: string; count: number } | null>(null);
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });

  // Crafting Grid state
  const gridSize = isCraftingTableOpen ? 3 : 2;
  const [craftGrid, setCraftGrid] = useState<(string | null)[]>(new Array(gridSize * gridSize).fill(null));
  const [craftResult, setCraftResult] = useState<{ itemId: string; count: number } | null>(null);

  const textureMgr = TextureManager.getInstance();
  const soundMgr = SoundManager.getInstance();

  useEffect(() => {
    setCraftGrid(new Array(gridSize * gridSize).fill(null));
    setCraftResult(null);
  }, [gridSize, isCraftingTableOpen]);

  // Recalculate crafting result whenever craftGrid changes
  useEffect(() => {
    const grid2D: (string | null)[][] = [];
    for (let r = 0; r < gridSize; r++) {
      grid2D[r] = [];
      for (let c = 0; c < gridSize; c++) {
        grid2D[r][c] = craftGrid[r * gridSize + c];
      }
    }
    const match = findCraftingMatch(grid2D, gridSize);
    setCraftResult(match);
  }, [craftGrid, gridSize]);

  if (!isOpen) return null;

  const handleMouseMove = (e: React.MouseEvent) => {
    setTooltipPos({ x: e.clientX + 14, y: e.clientY + 14 });
  };

  const getItemIcon = (itemId: string) => {
    const def = ITEMS[itemId];
    if (!def) return null;

    if (def.isBlock && def.blockType !== undefined) {
      const bDef = BLOCK_DEFS[def.blockType];
      const iconUrl = textureMgr.itemIcons[bDef.sideTexture] || textureMgr.itemIcons[bDef.topTexture];
      if (iconUrl) {
        return <img src={iconUrl} alt={def.namePl} className="w-8 h-8 pixelated pointer-events-none drop-shadow-[2px_2px_0px_rgba(0,0,0,0.5)]" />;
      }
    }

    const toolIcon = textureMgr.itemIcons[def.id];
    if (toolIcon) {
      return <img src={toolIcon} alt={def.namePl} className="w-8 h-8 pixelated pointer-events-none drop-shadow-[2px_2px_0px_rgba(0,0,0,0.5)]" />;
    }

    return (
      <div
        className="w-7 h-7 rounded-sm border border-black/40 flex items-center justify-center font-bold text-xs"
        style={{ backgroundColor: def.color || '#888' }}
      >
        {def.namePl.charAt(0)}
      </div>
    );
  };

  // Click on a slot (inventory or hotbar)
  const handleSlotClick = (
    type: 'inv' | 'hotbar' | 'craft',
    index: number,
    e: React.MouseEvent
  ) => {
    e.stopPropagation();
    soundMgr.playPop();

    let currentList = type === 'inv' ? [...inventory] : type === 'hotbar' ? [...hotbar] : null;

    if (type === 'craft') {
      const currentGrid = [...craftGrid];
      const slotVal = currentGrid[index];

      if (e.button === 2) {
        // Right click: place 1 held item
        if (heldItem && (!slotVal || slotVal === heldItem.itemId)) {
          currentGrid[index] = heldItem.itemId;
          if (heldItem.count > 1) {
            setHeldItem({ ...heldItem, count: heldItem.count - 1 });
          } else {
            setHeldItem(null);
          }
          setCraftGrid(currentGrid);
        }
      } else {
        // Left click
        if (heldItem) {
          if (!slotVal) {
            currentGrid[index] = heldItem.itemId;
            if (heldItem.count > 1) {
              setHeldItem({ ...heldItem, count: heldItem.count - 1 });
            } else {
              setHeldItem(null);
            }
          } else {
            // swap
            const oldVal = slotVal;
            currentGrid[index] = heldItem.itemId;
            setHeldItem({ itemId: oldVal, count: 1 });
          }
          setCraftGrid(currentGrid);
        } else if (slotVal) {
          // pickup
          setHeldItem({ itemId: slotVal, count: 1 });
          currentGrid[index] = null;
          setCraftGrid(currentGrid);
        }
      }
      return;
    }

    if (!currentList) return;
    const target = currentList[index];

    // Shift-click: transfer between hotbar & inventory
    if (e.shiftKey && target.itemId) {
      if (type === 'inv') {
        // Move to hotbar if space
        const emptyHIdx = hotbar.findIndex(s => !s.itemId || s.itemId === target.itemId);
        if (emptyHIdx !== -1) {
          const newHotbar = [...hotbar];
          if (newHotbar[emptyHIdx].itemId === target.itemId) {
            newHotbar[emptyHIdx].count += target.count;
          } else {
            newHotbar[emptyHIdx] = { ...target };
          }
          currentList[index] = { itemId: '', count: 0 };
          onUpdateInventory(currentList, newHotbar);
        }
      } else {
        // Move to main inventory
        const emptyInvIdx = inventory.findIndex(s => !s.itemId || s.itemId === target.itemId);
        if (emptyInvIdx !== -1) {
          const newInv = [...inventory];
          if (newInv[emptyInvIdx].itemId === target.itemId) {
            newInv[emptyInvIdx].count += target.count;
          } else {
            newInv[emptyInvIdx] = { ...target };
          }
          currentList[index] = { itemId: '', count: 0 };
          onUpdateInventory(newInv, currentList);
        }
      }
      return;
    }

    if (e.button === 2) {
      // Right click
      if (heldItem) {
        if (!target.itemId) {
          currentList[index] = { itemId: heldItem.itemId, count: 1 };
          if (heldItem.count > 1) {
            setHeldItem({ ...heldItem, count: heldItem.count - 1 });
          } else {
            setHeldItem(null);
          }
        } else if (target.itemId === heldItem.itemId) {
          currentList[index].count += 1;
          if (heldItem.count > 1) {
            setHeldItem({ ...heldItem, count: heldItem.count - 1 });
          } else {
            setHeldItem(null);
          }
        }
      } else if (target.itemId && target.count > 1) {
        // Split stack in half
        const half = Math.floor(target.count / 2);
        const rem = target.count - half;
        setHeldItem({ itemId: target.itemId, count: half });
        currentList[index].count = rem;
      }
    } else {
      // Left click
      if (!heldItem) {
        if (target.itemId) {
          setHeldItem({ itemId: target.itemId, count: target.count });
          currentList[index] = { itemId: '', count: 0 };
        }
      } else {
        if (!target.itemId) {
          currentList[index] = { itemId: heldItem.itemId, count: heldItem.count };
          setHeldItem(null);
        } else if (target.itemId === heldItem.itemId) {
          currentList[index].count += heldItem.count;
          setHeldItem(null);
        } else {
          // swap
          const oldHeld = heldItem;
          setHeldItem({ itemId: target.itemId, count: target.count });
          currentList[index] = { itemId: oldHeld.itemId, count: oldHeld.count };
        }
      }
    }

    if (type === 'inv') {
      onUpdateInventory(currentList, hotbar);
    } else {
      onUpdateInventory(inventory, currentList);
    }
  };

  // Take crafting result
  const handleTakeCraftResult = () => {
    if (!craftResult) return;
    soundMgr.playPop();

    // Give to held item or inventory
    if (heldItem && heldItem.itemId === craftResult.itemId) {
      setHeldItem({ ...heldItem, count: heldItem.count + craftResult.count });
    } else if (!heldItem) {
      setHeldItem({ itemId: craftResult.itemId, count: craftResult.count });
    } else {
      return; // Cannot hold two different items
    }

    // Clear crafting grid
    const newGrid = craftGrid.map(() => null);
    setCraftGrid(newGrid);
  };

  // Creative Mode: Click to get full stack (64) of any item
  const handleCreativePick = (itemId: string) => {
    soundMgr.playPop();
    const newHotbar = [...hotbar];
    const emptyIdx = newHotbar.findIndex(s => !s.itemId || s.itemId === itemId);
    if (emptyIdx !== -1) {
      newHotbar[emptyIdx] = { itemId, count: 64 };
      onUpdateInventory(inventory, newHotbar);
    } else {
      newHotbar[0] = { itemId, count: 64 };
      onUpdateInventory(inventory, newHotbar);
    }
  };

  const filteredCreativeItems = Object.keys(ITEMS).filter(id => {
    const item = ITEMS[id];
    return item.namePl.toLowerCase().includes(searchTerm.toLowerCase()) ||
           item.name.toLowerCase().includes(searchTerm.toLowerCase());
  });

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs select-none"
      onMouseMove={handleMouseMove}
      onClick={() => {
        // Drop held item back into first empty inventory slot
        if (heldItem) {
          const newInv = [...inventory];
          const emptyIdx = newInv.findIndex(s => !s.itemId);
          if (emptyIdx !== -1) {
            newInv[emptyIdx] = { ...heldItem };
            onUpdateInventory(newInv, hotbar);
            setHeldItem(null);
          }
        }
      }}
    >
      <div
        className="mc-panel p-4 rounded-md shadow-2xl relative max-w-[620px] w-full"
        onClick={e => e.stopPropagation()}
        onContextMenu={e => e.preventDefault()}
      >
        {/* Header with Title and Close Button */}
        <div className="flex justify-between items-center mb-3 border-b-2 border-[#555] pb-2">
          <div className="flex gap-2 items-center">
            <span className="font-pixel text-sm text-[#3f3f3f]">
              {isCraftingTableOpen
                ? 'Stół Rzemieślniczy (Crafting Table 3x3)'
                : activeTab === 'creative'
                ? 'Katalog Przedmiotów (Tryb Kreatywny)'
                : 'Ekwipunek Gracza (Inventory)'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {gameMode === 'creative' && !isCraftingTableOpen && (
              <div className="flex gap-1 text-xs font-pixel">
                <button
                  onClick={() => setActiveTab('survival')}
                  className={`px-2 py-1 mc-button ${activeTab === 'survival' ? 'bg-[#555] text-white' : ''}`}
                >
                  Ekwipunek
                </button>
                <button
                  onClick={() => setActiveTab('creative')}
                  className={`px-2 py-1 mc-button ${activeTab === 'creative' ? 'bg-[#555] text-white' : ''}`}
                >
                  Katalog
                </button>
              </div>
            )}
            <button
              onClick={onClose}
              className="p-1 mc-button rounded hover:bg-red-600 text-white"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        {/* Content Tabs */}
        {activeTab === 'creative' && !isCraftingTableOpen ? (
          <div>
            <div className="flex items-center gap-2 mb-3 bg-[#a0a0a0] p-1.5 rounded border border-black/40">
              <Search size={16} className="text-[#333]" />
              <input
                type="text"
                placeholder="Szukaj przedmiotu lub bloku..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="bg-transparent font-pixel text-xs text-[#222] focus:outline-hidden w-full placeholder:text-[#555]"
              />
            </div>

            <div className="grid grid-cols-9 gap-1.5 max-h-[280px] overflow-y-auto p-1 bg-[#8b8b8b] border-2 border-t-[#373737] border-l-[#373737] border-b-white border-r-white">
              {filteredCreativeItems.map(itemId => {
                return (
                  <div
                    key={itemId}
                    onClick={() => handleCreativePick(itemId)}
                    onMouseEnter={() => setHoveredItem({ itemId, count: 64 })}
                    onMouseLeave={() => setHoveredItem(null)}
                    className="w-10 h-10 mc-slot flex items-center justify-center cursor-pointer transition-all hover:scale-105"
                  >
                    {getItemIcon(itemId)}
                  </div>
                );
              })}
            </div>
            <p className="mt-2 text-xs text-[#333] font-vt323">
              * Kliknij dowolny przedmiot, aby dodać pełen stos (x64) do paska szybkiego wyboru.
            </p>
          </div>
        ) : (
          <div>
            {/* Top Area: Character Preview + Crafting Area */}
            <div className="flex justify-between items-center gap-6 mb-4 px-2">
              {/* Character Avatar Box */}
              <div className="w-24 h-28 bg-[#8b8b8b] border-2 border-t-[#373737] border-l-[#373737] border-b-white border-r-white flex flex-col items-center justify-center relative shadow-inner">
                {/* 2D Steve Silhouette / Avatar */}
                <div className="w-8 h-8 bg-[#b88b68] border border-black rounded-xs mb-1 relative">
                  {/* Hair */}
                  <div className="w-full h-2.5 bg-[#4a2e18]" />
                  {/* Eyes */}
                  <div className="absolute bottom-2 left-1.5 w-1.5 h-1 bg-white">
                    <div className="w-1 h-1 bg-blue-700" />
                  </div>
                  <div className="absolute bottom-2 right-1.5 w-1.5 h-1 bg-white">
                    <div className="w-1 h-1 bg-blue-700" />
                  </div>
                  {/* Beard/Nose */}
                  <div className="absolute bottom-0.5 left-2.5 w-3 h-1 bg-[#8a5d3b]" />
                </div>
                {/* Shirt */}
                <div className="w-10 h-10 bg-[#00aaaa] border border-black rounded-xs mb-0.5" />
                {/* Pants */}
                <div className="w-8 h-6 bg-[#0000aa] border border-black rounded-xs" />
                <span className="absolute bottom-0.5 font-pixel text-[8px] text-white drop-shadow">Steve</span>
              </div>

              {/* Crafting Grid */}
              <div className="flex items-center gap-3">
                <div className="flex flex-col">
                  <span className="font-pixel text-[10px] text-[#3f3f3f] mb-1">
                    {isCraftingTableOpen ? 'Wytwarzanie (3x3)' : 'Wytwarzanie (2x2)'}
                  </span>
                  <div
                    className="grid gap-1 bg-[#8b8b8b] p-1.5 border-2 border-t-[#373737] border-l-[#373737] border-b-white border-r-white"
                    style={{ gridTemplateColumns: `repeat(${gridSize}, minmax(0, 1fr))` }}
                  >
                    {craftGrid.map((item, idx) => (
                      <div
                        key={idx}
                        onClick={e => handleSlotClick('craft', idx, e)}
                        onContextMenu={e => handleSlotClick('craft', idx, e)}
                        className="w-10 h-10 mc-slot flex items-center justify-center cursor-pointer"
                      >
                        {item && getItemIcon(item)}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Crafting Arrow */}
                <div className="flex items-center justify-center px-1">
                  <span className="text-[#3f3f3f] font-pixel text-xl font-bold">➔</span>
                </div>

                {/* Result Slot */}
                <div className="flex flex-col items-center">
                  <span className="font-pixel text-[10px] text-[#3f3f3f] mb-1">Wynik</span>
                  <div
                    onClick={handleTakeCraftResult}
                    onMouseEnter={() => craftResult && setHoveredItem(craftResult)}
                    onMouseLeave={() => setHoveredItem(null)}
                    className="w-12 h-12 mc-slot flex items-center justify-center cursor-pointer bg-[#999] hover:bg-[#a8a8a8] relative"
                  >
                    {craftResult && (
                      <>
                        {getItemIcon(craftResult.itemId)}
                        <span className="absolute bottom-0.5 right-1 font-pixel text-xs text-white drop-shadow-[2px_2px_0px_#000]">
                          {craftResult.count}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Inventory Label */}
            <div className="font-pixel text-[10px] text-[#3f3f3f] mb-1 px-1">
              Ekwipunek (3x9)
            </div>

            {/* Main Inventory 3x9 */}
            <div className="grid grid-cols-9 gap-1 mb-3 p-1.5 bg-[#8b8b8b] border-2 border-t-[#373737] border-l-[#373737] border-b-white border-r-white">
              {inventory.map((slot, idx) => (
                <div
                  key={idx}
                  onClick={e => handleSlotClick('inv', idx, e)}
                  onContextMenu={e => handleSlotClick('inv', idx, e)}
                  onMouseEnter={() => slot.itemId && setHoveredItem(slot)}
                  onMouseLeave={() => setHoveredItem(null)}
                  className="w-10 h-10 mc-slot flex items-center justify-center cursor-pointer relative"
                >
                  {slot.itemId && getItemIcon(slot.itemId)}
                  {slot.count > 1 && (
                    <span className="absolute bottom-0.5 right-1 font-pixel text-[10px] text-white drop-shadow-[2px_2px_0px_#000] pointer-events-none">
                      {slot.count}
                    </span>
                  )}
                </div>
              ))}
            </div>

            {/* Hotbar Label */}
            <div className="font-pixel text-[10px] text-[#3f3f3f] mb-1 px-1">
              Pasek szybkiego wyboru (Hotbar 1-9)
            </div>

            {/* Hotbar 1x9 */}
            <div className="grid grid-cols-9 gap-1 p-1.5 bg-[#8b8b8b] border-2 border-t-[#373737] border-l-[#373737] border-b-white border-r-white">
              {hotbar.map((slot, idx) => (
                <div
                  key={idx}
                  onClick={e => handleSlotClick('hotbar', idx, e)}
                  onContextMenu={e => handleSlotClick('hotbar', idx, e)}
                  onMouseEnter={() => slot.itemId && setHoveredItem(slot)}
                  onMouseLeave={() => setHoveredItem(null)}
                  className="w-10 h-10 mc-slot flex items-center justify-center cursor-pointer relative"
                >
                  {slot.itemId && getItemIcon(slot.itemId)}
                  {slot.count > 1 && (
                    <span className="absolute bottom-0.5 right-1 font-pixel text-[10px] text-white drop-shadow-[2px_2px_0px_#000] pointer-events-none">
                      {slot.count}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Floating Mouse Cursor Held Item */}
        {heldItem && (
          <div
            className="fixed pointer-events-none z-50 flex items-center justify-center"
            style={{ left: tooltipPos.x - 16, top: tooltipPos.y - 16 }}
          >
            {getItemIcon(heldItem.itemId)}
            {heldItem.count > 1 && (
              <span className="absolute bottom-0 right-0 font-pixel text-xs text-white drop-shadow-[2px_2px_0px_#000]">
                {heldItem.count}
              </span>
            )}
          </div>
        )}

        {/* Hover Tooltip */}
        {hoveredItem && !heldItem && ITEMS[hoveredItem.itemId] && (
          <div
            className="fixed z-50 pointer-events-none bg-[#110114]/95 border-2 border-[#2b085e] px-2.5 py-1.5 rounded text-white shadow-xl max-w-[200px]"
            style={{ left: tooltipPos.x, top: tooltipPos.y }}
          >
            <div className="font-pixel text-xs text-white mb-0.5">
              {ITEMS[hoveredItem.itemId].namePl}
            </div>
            <div className="font-vt323 text-xs text-gray-400">
              {ITEMS[hoveredItem.itemId].name}
            </div>
            {ITEMS[hoveredItem.itemId].attackDamage && (
              <div className="text-[10px] text-emerald-400 font-pixel mt-1">
                +{ITEMS[hoveredItem.itemId].attackDamage} Obrażeń ataku
              </div>
            )}
            {ITEMS[hoveredItem.itemId].miningSpeedMultiplier && (
              <div className="text-[10px] text-yellow-300 font-pixel mt-0.5">
                Szybkość wydobycia: x{ITEMS[hoveredItem.itemId].miningSpeedMultiplier}
              </div>
            )}
            {ITEMS[hoveredItem.itemId].foodRestore && (
              <div className="text-[10px] text-amber-300 font-pixel mt-0.5">
                Przywraca głód: +{ITEMS[hoveredItem.itemId].foodRestore}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
