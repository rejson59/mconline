import React from 'react';
import { InventorySlot } from '../types/game';
import { ITEMS, BLOCK_DEFS } from '../engine/blocks';
import { TextureManager } from '../engine/textures';

interface HeldItemArmProps {
  heldSlot: InventorySlot | null;
  isSwinging: boolean;
  isWalking: boolean;
}

export const HeldItemArm: React.FC<HeldItemArmProps> = ({
  heldSlot,
  isSwinging,
  isWalking,
}) => {
  const textureMgr = TextureManager.getInstance();
  const itemDef = heldSlot?.itemId ? ITEMS[heldSlot.itemId] : null;

  // Visual icon or texture
  let itemIconUrl: string | null = null;
  if (itemDef) {
    if (itemDef.isBlock && itemDef.blockType !== undefined) {
      const bDef = BLOCK_DEFS[itemDef.blockType];
      itemIconUrl = textureMgr.itemIcons[bDef.sideTexture] || textureMgr.itemIcons[bDef.topTexture];
    } else {
      itemIconUrl = textureMgr.itemIcons[itemDef.id] || null;
    }
  }

  return (
    <div className="fixed bottom-0 right-12 pointer-events-none z-20 select-none">
      <div
        className={`relative transition-transform duration-75 origin-bottom-right ${
          isWalking ? 'animate-hand-bob' : ''
        } ${isSwinging ? 'animate-hand-swing' : ''}`}
      >
        {itemIconUrl ? (
          <div className="w-40 h-40 flex items-end justify-end filter drop-shadow-[4px_6px_0px_rgba(0,0,0,0.6)]">
            <img
              src={itemIconUrl}
              alt="Held item"
              className="w-32 h-32 pixelated transform -rotate-12 translate-y-4 translate-x-2"
            />
          </div>
        ) : (
          /* Steve's Arm (Fist) */
          <div className="relative w-28 h-36 origin-bottom-right transform rotate-12 translate-y-4 shadow-xl">
            {/* Cyan sleeve */}
            <div className="w-20 h-16 bg-[#00aaaa] border-l-2 border-t-2 border-[#007777] rounded-t-xs" />
            {/* Skin arm */}
            <div className="w-20 h-24 bg-[#b88b68] border-l-2 border-b-2 border-[#80583b]">
              {/* Hand shading */}
              <div className="w-full h-8 bg-[#ab7e5b] mt-12" />
            </div>
          </div>
        )}
      </div>

      <style>{`
        @keyframes handBob {
          0% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-8px) rotate(-2deg); }
          100% { transform: translateY(0px) rotate(0deg); }
        }
        @keyframes handSwing {
          0% { transform: translateY(0px) rotate(0deg); }
          30% { transform: translateY(-24px) rotate(-35deg) scale(1.1); }
          70% { transform: translateY(12px) rotate(15deg); }
          100% { transform: translateY(0px) rotate(0deg); }
        }
        .animate-hand-bob {
          animation: handBob 0.6s infinite ease-in-out;
        }
        .animate-hand-swing {
          animation: handSwing 0.22s ease-in-out;
        }
      `}</style>
    </div>
  );
};
