import { CraftingRecipe } from '../types/game';

export const RECIPES: CraftingRecipe[] = [
  // 1 Wood Log -> 4 Planks (Shapeless)
  {
    isShapeless: true,
    pattern: [['block_oak_log']],
    result: { itemId: 'block_oak_planks', count: 4 }
  },
  {
    isShapeless: true,
    pattern: [['block_birch_log']],
    result: { itemId: 'block_oak_planks', count: 4 }
  },

  // 2 Planks vertical -> 4 Sticks
  {
    pattern: [
      ['block_oak_planks'],
      ['block_oak_planks']
    ],
    result: { itemId: 'item_stick', count: 4 }
  },

  // 4 Planks (2x2) -> Crafting Table
  {
    pattern: [
      ['block_oak_planks', 'block_oak_planks'],
      ['block_oak_planks', 'block_oak_planks']
    ],
    result: { itemId: 'block_crafting_table', count: 1 }
  },

  // 1 Coal + 1 Stick -> 4 Torches
  {
    pattern: [
      ['item_coal'],
      ['item_stick']
    ],
    result: { itemId: 'block_torch', count: 4 }
  },

  // 4 Sand -> Sandstone
  {
    pattern: [
      ['block_sand', 'block_sand'],
      ['block_sand', 'block_sand']
    ],
    result: { itemId: 'block_sandstone', count: 1 }
  },

  // 8 Cobblestone -> Furnace (3x3 ring)
  {
    pattern: [
      ['block_cobblestone', 'block_cobblestone', 'block_cobblestone'],
      ['block_cobblestone', null, 'block_cobblestone'],
      ['block_cobblestone', 'block_cobblestone', 'block_cobblestone']
    ],
    result: { itemId: 'block_furnace', count: 1 }
  },

  // TNT: 4 Sand + 5 Coal/Gunpowder
  {
    pattern: [
      ['block_sand', 'item_coal', 'block_sand'],
      ['item_coal', 'block_sand', 'item_coal'],
      ['block_sand', 'item_coal', 'block_sand']
    ],
    result: { itemId: 'block_tnt', count: 1 }
  },

  // --- WOODEN TOOLS ---
  {
    pattern: [
      ['block_oak_planks', 'block_oak_planks', 'block_oak_planks'],
      [null, 'item_stick', null],
      [null, 'item_stick', null]
    ],
    result: { itemId: 'item_wooden_pickaxe', count: 1 }
  },
  {
    pattern: [
      ['block_oak_planks', 'block_oak_planks'],
      ['block_oak_planks', 'item_stick'],
      [null, 'item_stick']
    ],
    result: { itemId: 'item_wooden_axe', count: 1 }
  },
  {
    pattern: [
      ['block_oak_planks'],
      ['item_stick'],
      ['item_stick']
    ],
    result: { itemId: 'item_wooden_shovel', count: 1 }
  },
  {
    pattern: [
      ['block_oak_planks'],
      ['block_oak_planks'],
      ['item_stick']
    ],
    result: { itemId: 'item_wooden_sword', count: 1 }
  },

  // --- STONE TOOLS ---
  {
    pattern: [
      ['block_cobblestone', 'block_cobblestone', 'block_cobblestone'],
      [null, 'item_stick', null],
      [null, 'item_stick', null]
    ],
    result: { itemId: 'item_stone_pickaxe', count: 1 }
  },
  {
    pattern: [
      ['block_cobblestone', 'block_cobblestone'],
      ['block_cobblestone', 'item_stick'],
      [null, 'item_stick']
    ],
    result: { itemId: 'item_stone_axe', count: 1 }
  },
  {
    pattern: [
      ['block_cobblestone'],
      ['item_stick'],
      ['item_stick']
    ],
    result: { itemId: 'item_stone_shovel', count: 1 }
  },
  {
    pattern: [
      ['block_cobblestone'],
      ['block_cobblestone'],
      ['item_stick']
    ],
    result: { itemId: 'item_stone_sword', count: 1 }
  },

  // --- IRON TOOLS ---
  {
    pattern: [
      ['item_raw_iron', 'item_raw_iron', 'item_raw_iron'],
      [null, 'item_stick', null],
      [null, 'item_stick', null]
    ],
    result: { itemId: 'item_iron_pickaxe', count: 1 }
  },
  {
    pattern: [
      ['item_raw_iron', 'item_raw_iron'],
      ['item_raw_iron', 'item_stick'],
      [null, 'item_stick']
    ],
    result: { itemId: 'item_iron_axe', count: 1 }
  },
  {
    pattern: [
      ['item_raw_iron'],
      ['item_stick'],
      ['item_stick']
    ],
    result: { itemId: 'item_iron_shovel', count: 1 }
  },
  {
    pattern: [
      ['item_raw_iron'],
      ['item_raw_iron'],
      ['item_stick']
    ],
    result: { itemId: 'item_iron_sword', count: 1 }
  },

  // --- DIAMOND TOOLS ---
  {
    pattern: [
      ['item_diamond', 'item_diamond', 'item_diamond'],
      [null, 'item_stick', null],
      [null, 'item_stick', null]
    ],
    result: { itemId: 'item_diamond_pickaxe', count: 1 }
  },
  {
    pattern: [
      ['item_diamond', 'item_diamond'],
      ['item_diamond', 'item_stick'],
      [null, 'item_stick']
    ],
    result: { itemId: 'item_diamond_axe', count: 1 }
  },
  {
    pattern: [
      ['item_diamond'],
      ['item_stick'],
      ['item_stick']
    ],
    result: { itemId: 'item_diamond_shovel', count: 1 }
  },
  {
    pattern: [
      ['item_diamond'],
      ['item_diamond'],
      ['item_stick']
    ],
    result: { itemId: 'item_diamond_sword', count: 1 }
  },

  // Bookshelf (Planks + Planks)
  {
    pattern: [
      ['block_oak_planks', 'block_oak_planks', 'block_oak_planks'],
      ['block_oak_planks', 'block_oak_planks', 'block_oak_planks']
    ],
    result: { itemId: 'block_bookshelf', count: 1 }
  }
];

export function findCraftingMatch(
  grid: (string | null)[][],
  gridSize: number // 2 or 3
): { itemId: string; count: number } | null {
  // Trim empty borders of grid
  let minR = gridSize, maxR = -1, minC = gridSize, maxC = -1;
  let hasItems = false;
  const nonNullItems: string[] = [];

  for (let r = 0; r < gridSize; r++) {
    for (let c = 0; c < gridSize; c++) {
      const item = grid[r][c];
      if (item) {
        hasItems = true;
        nonNullItems.push(item);
        if (r < minR) minR = r;
        if (r > maxR) maxR = r;
        if (c < minC) minC = c;
        if (c > maxC) maxC = c;
      }
    }
  }

  if (!hasItems) return null;

  // Extract trimmed grid
  const subRows = maxR - minR + 1;
  const subCols = maxC - minC + 1;
  const trimmed: (string | null)[][] = [];

  for (let r = 0; r < subRows; r++) {
    trimmed[r] = [];
    for (let c = 0; c < subCols; c++) {
      trimmed[r][c] = grid[minR + r][minC + c];
    }
  }

  // Check recipes
  for (const recipe of RECIPES) {
    if (recipe.isShapeless) {
      // Compare sorted list of items
      const recipeItems: string[] = [];
      for (const row of recipe.pattern) {
        for (const it of row) {
          if (it) recipeItems.push(it);
        }
      }
      if (recipeItems.length === nonNullItems.length) {
        const s1 = [...recipeItems].sort().join(',');
        const s2 = [...nonNullItems].sort().join(',');
        if (s1 === s2) {
          return { ...recipe.result };
        }
      }
      continue;
    }

    // Shaped match
    const patH = recipe.pattern.length;
    const patW = recipe.pattern[0].length;

    if (patH === subRows && patW === subCols) {
      let match = true;
      for (let r = 0; r < patH; r++) {
        for (let c = 0; c < patW; c++) {
          const req = recipe.pattern[r][c];
          const actual = trimmed[r][c];
          if (req !== actual) {
            match = false;
            break;
          }
        }
        if (!match) break;
      }
      if (match) return { ...recipe.result };
    }
  }

  return null;
}
