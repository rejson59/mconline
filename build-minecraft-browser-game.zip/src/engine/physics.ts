import * as THREE from 'three';
import { WorldManager } from './world';
import { BlockType } from '../types/game';
import { BLOCK_DEFS } from './blocks';

export interface AABB {
  minX: number;
  minY: number;
  minZ: number;
  maxX: number;
  maxY: number;
  maxZ: number;
}

export class PhysicsController {
  public position: THREE.Vector3 = new THREE.Vector3(0, 32, 0);
  public velocity: THREE.Vector3 = new THREE.Vector3(0, 0, 0);
  public cameraOffset: THREE.Vector3 = new THREE.Vector3(0, 1.62, 0);

  public width: number = 0.6;
  public height: number = 1.8;

  public onGround: boolean = false;
  public inWater: boolean = false;
  public isFlying: boolean = false;
  public isSprinting: boolean = false;
  public isSneaking: boolean = false;

  public gravity: number = 28.0;
  public jumpStrength: number = 8.5;
  public walkSpeed: number = 4.3;
  public sprintMultiplier: number = 1.35;
  public flySpeed: number = 12.0;

  private world: WorldManager;

  constructor(world: WorldManager) {
    this.world = world;
  }

  public getAABB(pos: THREE.Vector3 = this.position): AABB {
    const hw = this.width / 2;
    return {
      minX: pos.x - hw,
      minY: pos.y,
      minZ: pos.z - hw,
      maxX: pos.x + hw,
      maxY: pos.y + this.height,
      maxZ: pos.z + hw,
    };
  }

  public isSolidBlock(x: number, y: number, z: number): boolean {
    const block = this.world.getBlock(x, y, z);
    if (block === BlockType.AIR || block === BlockType.WATER) return false;
    const def = BLOCK_DEFS[block];
    return !def.isPlant;
  }

  public update(
    delta: number,
    moveInput: { forward: number; strafe: number; jump: boolean; sneak: boolean; sprint: boolean },
    cameraYaw: number
  ) {
    const dt = Math.min(delta, 0.1);

    // Check water
    const eyeBlock = this.world.getBlock(
      Math.floor(this.position.x),
      Math.floor(this.position.y + 1.2),
      Math.floor(this.position.z)
    );
    const feetBlock = this.world.getBlock(
      Math.floor(this.position.x),
      Math.floor(this.position.y + 0.1),
      Math.floor(this.position.z)
    );
    this.inWater = eyeBlock === BlockType.WATER || feetBlock === BlockType.WATER;

    // Movement direction from yaw
    const forwardVec = new THREE.Vector3(-Math.sin(cameraYaw), 0, -Math.cos(cameraYaw));
    const rightVec = new THREE.Vector3(Math.cos(cameraYaw), 0, -Math.sin(cameraYaw));

    const moveDir = new THREE.Vector3(0, 0, 0);
    moveDir.addScaledVector(forwardVec, moveInput.forward);
    moveDir.addScaledVector(rightVec, moveInput.strafe);
    if (moveDir.lengthSq() > 0) {
      moveDir.normalize();
    }

    this.isSprinting = moveInput.sprint && moveInput.forward > 0 && !this.isSneaking && !this.inWater;
    this.isSneaking = moveInput.sneak && !this.isFlying;

    // Calculate horizontal speed
    let speed = this.walkSpeed;
    if (this.isFlying) {
      speed = this.flySpeed;
      if (this.isSprinting) speed *= 1.6;
    } else if (this.isSprinting) {
      speed *= this.sprintMultiplier;
    } else if (this.isSneaking) {
      speed *= 0.35;
    } else if (this.inWater) {
      speed *= 0.65;
    }

    if (this.isFlying) {
      // Flight physics
      this.velocity.x = moveDir.x * speed;
      this.velocity.z = moveDir.z * speed;
      this.velocity.y = 0;
      if (moveInput.jump) this.velocity.y = speed;
      if (moveInput.sneak) this.velocity.y = -speed;
    } else {
      // Normal physics
      const targetVx = moveDir.x * speed;
      const targetVz = moveDir.z * speed;
      const accel = this.onGround ? 18.0 : 4.0;

      this.velocity.x += (targetVx - this.velocity.x) * Math.min(1.0, accel * dt);
      this.velocity.z += (targetVz - this.velocity.z) * Math.min(1.0, accel * dt);

      // Water buoyancy & jumping
      if (this.inWater) {
        this.velocity.y -= this.gravity * 0.25 * dt;
        if (moveInput.jump) {
          this.velocity.y = 3.5;
        } else if (moveInput.sneak) {
          this.velocity.y = -3.5;
        }
        this.velocity.y *= 0.9;
      } else {
        // Gravity
        this.velocity.y -= this.gravity * dt;
        if (this.velocity.y < -40.0) this.velocity.y = -40.0;

        // Jump
        if (moveInput.jump && this.onGround) {
          this.velocity.y = this.jumpStrength;
          this.onGround = false;
        }
      }
    }

    // Perform collision resolution along each axis
    this.moveWithCollision(this.velocity.x * dt, this.velocity.y * dt, this.velocity.z * dt);
  }

  // Resolves collisions against solid voxel blocks
  private moveWithCollision(dx: number, dy: number, dz: number) {
    if (this.isFlying) {
      this.position.x += dx;
      this.position.y += dy;
      this.position.z += dz;
      return;
    }

    // 1. Move Y
    this.position.y += dy;
    let aabb = this.getAABB();
    this.onGround = false;

    let minBX = Math.floor(aabb.minX);
    let maxBX = Math.floor(aabb.maxX);
    let minBY = Math.floor(aabb.minY);
    let maxBY = Math.floor(aabb.maxY);
    let minBZ = Math.floor(aabb.minZ);
    let maxBZ = Math.floor(aabb.maxZ);

    for (let by = minBY; by <= maxBY; by++) {
      for (let bx = minBX; bx <= maxBX; bx++) {
        for (let bz = minBZ; bz <= maxBZ; bz++) {
          if (this.isSolidBlock(bx, by, bz)) {
            if (dy < 0) {
              // Hit ground
              this.position.y = by + 1.0;
              this.velocity.y = 0;
              this.onGround = true;
            } else if (dy > 0) {
              // Hit ceiling
              this.position.y = by - this.height;
              this.velocity.y = 0;
            }
            aabb = this.getAABB();
          }
        }
      }
    }

    // 2. Move X
    this.position.x += dx;
    aabb = this.getAABB();
    minBX = Math.floor(aabb.minX);
    maxBX = Math.floor(aabb.maxX);
    minBY = Math.floor(aabb.minY);
    maxBY = Math.floor(aabb.maxY);
    minBZ = Math.floor(aabb.minZ);
    maxBZ = Math.floor(aabb.maxZ);

    for (let bx = minBX; bx <= maxBX; bx++) {
      for (let by = minBY; by <= maxBY; by++) {
        for (let bz = minBZ; bz <= maxBZ; bz++) {
          if (this.isSolidBlock(bx, by, bz)) {
            if (dx > 0) {
              this.position.x = bx - this.width / 2;
              this.velocity.x = 0;
            } else if (dx < 0) {
              this.position.x = bx + 1.0 + this.width / 2;
              this.velocity.x = 0;
            }
            aabb = this.getAABB();
          }
        }
      }
    }

    // 3. Move Z
    this.position.z += dz;
    aabb = this.getAABB();
    minBX = Math.floor(aabb.minX);
    maxBX = Math.floor(aabb.maxX);
    minBY = Math.floor(aabb.minY);
    maxBY = Math.floor(aabb.maxY);
    minBZ = Math.floor(aabb.minZ);
    maxBZ = Math.floor(aabb.maxZ);

    for (let bz = minBZ; bz <= maxBZ; bz++) {
      for (let by = minBY; by <= maxBY; by++) {
        for (let bx = minBX; bx <= maxBX; bx++) {
          if (this.isSolidBlock(bx, by, bz)) {
            if (dz > 0) {
              this.position.z = bz - this.width / 2;
              this.velocity.z = 0;
            } else if (dz < 0) {
              this.position.z = bz + 1.0 + this.width / 2;
              this.velocity.z = 0;
            }
            aabb = this.getAABB();
          }
        }
      }
    }
  }

  public getEyePosition(): THREE.Vector3 {
    return new THREE.Vector3(
      this.position.x,
      this.position.y + (this.isSneaking ? 1.45 : 1.62),
      this.position.z
    );
  }
}
