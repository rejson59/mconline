import * as THREE from 'three';
import { MobEntity, DroppedItem, BlockType } from '../types/game';
import { WorldManager } from './world';
import { SoundManager } from './audio';
import { ITEMS } from './blocks';

export class EntityManager {
  public mobs: MobEntity[] = [];
  public droppedItems: DroppedItem[] = [];
  private scene: THREE.Scene;
  private world: WorldManager;
  private sound: SoundManager;

  // Particle pool
  public particles: { mesh: THREE.Mesh; vx: number; vy: number; vz: number; life: number; maxLife: number }[] = [];

  constructor(scene: THREE.Scene, world: WorldManager) {
    this.scene = scene;
    this.world = world;
    this.sound = SoundManager.getInstance();
  }

  // Create Minecraft Pig Model
  private createPigMesh(): THREE.Group {
    const group = new THREE.Group();
    const pinkMat = new THREE.MeshLambertMaterial({ color: 0xf0a19c });
    const darkPinkMat = new THREE.MeshLambertMaterial({ color: 0xdb837d });
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0x222222 });

    // Body: 10 x 8 x 16 (scaled down / 16)
    const bodyGeo = new THREE.BoxGeometry(0.7, 0.5, 1.0);
    const body = new THREE.Mesh(bodyGeo, pinkMat);
    body.position.y = 0.55;
    group.add(body);

    // Head: 8 x 8 x 8
    const headGroup = new THREE.Group();
    const headGeo = new THREE.BoxGeometry(0.5, 0.5, 0.5);
    const head = new THREE.Mesh(headGeo, pinkMat);
    headGroup.add(head);

    // Snout
    const snoutGeo = new THREE.BoxGeometry(0.25, 0.15, 0.1);
    const snout = new THREE.Mesh(snoutGeo, darkPinkMat);
    snout.position.set(0, -0.08, 0.28);
    headGroup.add(snout);

    // Eyes
    const eyeGeo = new THREE.BoxGeometry(0.08, 0.08, 0.02);
    const leftEye = new THREE.Mesh(eyeGeo, eyeMat);
    leftEye.position.set(-0.16, 0.05, 0.26);
    const rightEye = new THREE.Mesh(eyeGeo, eyeMat);
    rightEye.position.set(0.16, 0.05, 0.26);
    headGroup.add(leftEye, rightEye);

    headGroup.position.set(0, 0.65, 0.6);
    headGroup.name = 'head';
    group.add(headGroup);

    // 4 Legs
    const legGeo = new THREE.BoxGeometry(0.2, 0.4, 0.2);
    const legPositions = [
      [-0.22, 0.2, 0.35],
      [0.22, 0.2, 0.35],
      [-0.22, 0.2, -0.35],
      [0.22, 0.2, -0.35]
    ];

    legPositions.forEach((pos, idx) => {
      const leg = new THREE.Mesh(legGeo, pinkMat);
      leg.position.set(pos[0], pos[1], pos[2]);
      leg.name = `leg_${idx}`;
      group.add(leg);
    });

    return group;
  }

  // Create Zombie Model
  private createZombieMesh(): THREE.Group {
    const group = new THREE.Group();
    const skinMat = new THREE.MeshLambertMaterial({ color: 0x5a8848 });
    const shirtMat = new THREE.MeshLambertMaterial({ color: 0x228b99 });
    const pantsMat = new THREE.MeshLambertMaterial({ color: 0x2a3d7c });
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0x111111 });

    // Body
    const bodyGeo = new THREE.BoxGeometry(0.5, 0.75, 0.25);
    const body = new THREE.Mesh(bodyGeo, shirtMat);
    body.position.y = 1.05;
    group.add(body);

    // Head
    const headGroup = new THREE.Group();
    const headGeo = new THREE.BoxGeometry(0.5, 0.5, 0.5);
    const head = new THREE.Mesh(headGeo, skinMat);
    headGroup.add(head);

    // Eyes
    const eyeGeo = new THREE.BoxGeometry(0.08, 0.08, 0.02);
    const eyeL = new THREE.Mesh(eyeGeo, eyeMat);
    eyeL.position.set(-0.14, 0.05, 0.26);
    const eyeR = new THREE.Mesh(eyeGeo, eyeMat);
    eyeR.position.set(0.14, 0.05, 0.26);
    headGroup.add(eyeL, eyeR);

    headGroup.position.set(0, 1.65, 0);
    headGroup.name = 'head';
    group.add(headGroup);

    // Arms extended forward (iconic zombie pose!)
    const armGeo = new THREE.BoxGeometry(0.2, 0.2, 0.65);
    const leftArm = new THREE.Mesh(armGeo, shirtMat);
    leftArm.position.set(-0.35, 1.25, 0.32);
    leftArm.name = 'arm_left';
    const rightArm = new THREE.Mesh(armGeo, shirtMat);
    rightArm.position.set(0.35, 1.25, 0.32);
    rightArm.name = 'arm_right';
    group.add(leftArm, rightArm);

    // Legs
    const legGeo = new THREE.BoxGeometry(0.22, 0.7, 0.22);
    const leftLeg = new THREE.Mesh(legGeo, pantsMat);
    leftLeg.position.set(-0.14, 0.35, 0);
    leftLeg.name = 'leg_0';
    const rightLeg = new THREE.Mesh(legGeo, pantsMat);
    rightLeg.position.set(0.14, 0.35, 0);
    rightLeg.name = 'leg_1';
    group.add(leftLeg, rightLeg);

    return group;
  }

  // Create Sheep Model
  private createSheepMesh(): THREE.Group {
    const group = new THREE.Group();
    const woolMat = new THREE.MeshLambertMaterial({ color: 0xefefef });
    const skinMat = new THREE.MeshLambertMaterial({ color: 0x9b8577 });
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0x222222 });

    // Wool body
    const bodyGeo = new THREE.BoxGeometry(0.75, 0.65, 1.1);
    const body = new THREE.Mesh(bodyGeo, woolMat);
    body.position.y = 0.65;
    group.add(body);

    // Head
    const headGroup = new THREE.Group();
    const headGeo = new THREE.BoxGeometry(0.4, 0.4, 0.45);
    const head = new THREE.Mesh(headGeo, skinMat);
    headGroup.add(head);

    const eyeGeo = new THREE.BoxGeometry(0.06, 0.06, 0.02);
    const eyeL = new THREE.Mesh(eyeGeo, eyeMat);
    eyeL.position.set(-0.12, 0.05, 0.23);
    const eyeR = new THREE.Mesh(eyeGeo, eyeMat);
    eyeR.position.set(0.12, 0.05, 0.23);
    headGroup.add(eyeL, eyeR);

    headGroup.position.set(0, 0.8, 0.65);
    headGroup.name = 'head';
    group.add(headGroup);

    // 4 Legs
    const legGeo = new THREE.BoxGeometry(0.18, 0.45, 0.18);
    const legPositions = [
      [-0.22, 0.22, 0.35],
      [0.22, 0.22, 0.35],
      [-0.22, 0.22, -0.35],
      [0.22, 0.22, -0.35]
    ];
    legPositions.forEach((pos, idx) => {
      const leg = new THREE.Mesh(legGeo, skinMat);
      leg.position.set(pos[0], pos[1], pos[2]);
      leg.name = `leg_${idx}`;
      group.add(leg);
    });

    return group;
  }

  // Spawn Mob
  public spawnMob(type: 'pig' | 'sheep' | 'cow' | 'zombie', x: number, y: number, z: number): MobEntity {
    let mesh: THREE.Group;
    let maxHp = 10;
    if (type === 'pig') {
      mesh = this.createPigMesh();
      maxHp = 10;
    } else if (type === 'zombie') {
      mesh = this.createZombieMesh();
      maxHp = 20;
    } else {
      mesh = this.createSheepMesh();
      maxHp = 8;
    }

    mesh.position.set(x, y, z);
    this.scene.add(mesh);

    const mob: MobEntity = {
      id: Math.random().toString(36).substring(2, 9),
      type,
      x,
      y,
      z,
      vx: 0,
      vy: 0,
      vz: 0,
      yaw: Math.random() * Math.PI * 2,
      pitch: 0,
      health: maxHp,
      maxHealth: maxHp,
      animTime: 0,
      walkCycle: 0,
      isHurt: 0,
      mesh,
    };

    this.mobs.push(mob);
    return mob;
  }

  // Spawn Dropped Item
  public spawnDroppedItem(itemId: string, count: number, x: number, y: number, z: number) {
    const itemDef = ITEMS[itemId];
    const isBlock = itemDef?.isBlock;

    // Mini 3D mesh
    const geo = isBlock ? new THREE.BoxGeometry(0.35, 0.35, 0.35) : new THREE.BoxGeometry(0.25, 0.25, 0.08);
    const color = itemDef?.color ? parseInt(itemDef.color.replace('#', '0x')) : 0x4bede6;
    const mat = new THREE.MeshLambertMaterial({
      color,
      map: isBlock ? this.world.solidMaterial.map : null,
    });

    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, y, z);
    this.scene.add(mesh);

    const drop: DroppedItem = {
      id: Math.random().toString(36).substring(2, 9),
      itemId,
      count,
      x,
      y,
      z,
      vx: (Math.random() - 0.5) * 2.5,
      vy: 3.5 + Math.random() * 2.0,
      vz: (Math.random() - 0.5) * 2.5,
      age: 0,
      mesh,
    };

    this.droppedItems.push(drop);
  }

  // Spawn particles on block break or hit
  public spawnBlockBreakParticles(x: number, y: number, z: number, color: number = 0x866043, count: number = 16) {
    const pGeo = new THREE.BoxGeometry(0.08, 0.08, 0.08);
    const pMat = new THREE.MeshBasicMaterial({ color });

    for (let i = 0; i < count; i++) {
      const mesh = new THREE.Mesh(pGeo, pMat);
      mesh.position.set(
        x + 0.5 + (Math.random() - 0.5) * 0.6,
        y + 0.5 + (Math.random() - 0.5) * 0.6,
        z + 0.5 + (Math.random() - 0.5) * 0.6
      );
      this.scene.add(mesh);

      this.particles.push({
        mesh,
        vx: (Math.random() - 0.5) * 4.0,
        vy: 2.0 + Math.random() * 3.5,
        vz: (Math.random() - 0.5) * 4.0,
        life: 0,
        maxLife: 0.6 + Math.random() * 0.4,
      });
    }
  }

  // Update entities
  public update(delta: number, playerPos: THREE.Vector3, onPickupItem: (itemId: string, count: number) => void) {
    const dt = Math.min(delta, 0.1);

    // 1. Update Particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life += dt;
      if (p.life >= p.maxLife) {
        this.scene.remove(p.mesh);
        p.mesh.geometry.dispose();
        this.particles.splice(i, 1);
        continue;
      }
      p.vy -= 18.0 * dt;
      p.mesh.position.x += p.vx * dt;
      p.mesh.position.y += p.vy * dt;
      p.mesh.position.z += p.vz * dt;
      const scale = 1.0 - p.life / p.maxLife;
      p.mesh.scale.set(scale, scale, scale);
    }

    // 2. Update Dropped Items (Gravity, magnet pickup, bobbing)
    for (let i = this.droppedItems.length - 1; i >= 0; i--) {
      const item = this.droppedItems[i];
      item.age += dt;

      // Gravity & collision with ground
      const blockUnder = this.world.getBlock(Math.floor(item.x), Math.floor(item.y), Math.floor(item.z));
      if (blockUnder !== BlockType.AIR && blockUnder !== BlockType.WATER) {
        item.y = Math.floor(item.y) + 1.05;
        item.vy = 0;
        item.vx *= 0.8;
        item.vz *= 0.8;
      } else {
        item.vy -= 16.0 * dt;
        item.y += item.vy * dt;
        item.x += item.vx * dt;
        item.z += item.vz * dt;
      }

      // Magnet pull toward player
      const dx = playerPos.x - item.x;
      const dy = playerPos.y + 0.8 - item.y;
      const dz = playerPos.z - item.z;
      const distSq = dx * dx + dy * dy + dz * dz;

      if (distSq < 2.5 * 2.5 && item.age > 0.4) {
        const dist = Math.sqrt(distSq);
        item.x += (dx / dist) * 7.0 * dt;
        item.y += (dy / dist) * 7.0 * dt;
        item.z += (dz / dist) * 7.0 * dt;

        if (dist < 0.6) {
          // Collected!
          this.sound.playPop();
          onPickupItem(item.itemId, item.count);
          this.scene.remove(item.mesh);
          item.mesh.geometry.dispose();
          this.droppedItems.splice(i, 1);
          continue;
        }
      }

      // Visual spin & hover
      if (item.mesh) {
        item.mesh.position.set(item.x, item.y + Math.sin(item.age * 3.5) * 0.08, item.z);
        item.mesh.rotation.y += 2.0 * dt;
      }
    }

    // 3. Update Mobs AI & Animation
    for (let i = this.mobs.length - 1; i >= 0; i--) {
      const mob = this.mobs[i];
      mob.animTime += dt;

      if (mob.isHurt > 0) {
        mob.isHurt -= dt;
      }

      // Check distance to player
      const pDistX = playerPos.x - mob.x;
      const pDistZ = playerPos.z - mob.z;
      const distToPlayer = Math.sqrt(pDistX * pDistX + pDistZ * pDistZ);

      // AI Behavior
      if (mob.type === 'zombie' && distToPlayer < 14) {
        // Chase player!
        mob.yaw = Math.atan2(pDistX, pDistZ);
        mob.vx = Math.sin(mob.yaw) * 2.2;
        mob.vz = Math.cos(mob.yaw) * 2.2;
        mob.walkCycle += dt * 8.0;
      } else {
        // Wander around randomly
        if (Math.random() < 0.02) {
          mob.yaw += (Math.random() - 0.5) * 1.5;
        }
        if (Math.sin(mob.animTime * 0.6) > 0.2) {
          mob.vx = Math.sin(mob.yaw) * 1.0;
          mob.vz = Math.cos(mob.yaw) * 1.0;
          mob.walkCycle += dt * 5.0;
        } else {
          mob.vx = 0;
          mob.vz = 0;
        }
      }

      // Mob Gravity & Jump over 1-block obstacles
      mob.vy -= 22.0 * dt;
      mob.y += mob.vy * dt;
      mob.x += mob.vx * dt;
      mob.z += mob.vz * dt;

      const groundY = Math.floor(mob.y);
      const underBlock = this.world.getBlock(Math.floor(mob.x), groundY, Math.floor(mob.z));
      if (underBlock !== BlockType.AIR && underBlock !== BlockType.WATER) {
        mob.y = groundY + 1.0;
        mob.vy = 0;

        // Auto jump over 1 block in front
        const frontBlock = this.world.getBlock(
          Math.floor(mob.x + Math.sin(mob.yaw) * 0.5),
          groundY + 1,
          Math.floor(mob.z + Math.cos(mob.yaw) * 0.5)
        );
        if (frontBlock !== BlockType.AIR && frontBlock !== BlockType.WATER) {
          mob.vy = 6.0;
        }
      }

      // Sync 3D mesh
      if (mob.mesh) {
        mob.mesh.position.set(mob.x, mob.y, mob.z);
        mob.mesh.rotation.y = mob.yaw;

        // Red flash when hurt
        const isDamaged = mob.isHurt > 0;
        mob.mesh.traverse((child: any) => {
          if (child.isMesh && child.material) {
            child.material.color.setHex(isDamaged ? 0xff3333 : (mob.type === 'pig' ? 0xf0a19c : (mob.type === 'zombie' ? (child.name.includes('leg') ? 0x2a3d7c : 0x228b99) : 0xefefef)));
          }
        });

        // Leg swing animation
        const legSwing = Math.sin(mob.walkCycle) * 0.45;
        const leg0 = mob.mesh.getObjectByName('leg_0');
        const leg1 = mob.mesh.getObjectByName('leg_1');
        const leg2 = mob.mesh.getObjectByName('leg_2');
        const leg3 = mob.mesh.getObjectByName('leg_3');

        if (leg0) leg0.rotation.x = legSwing;
        if (leg1) leg1.rotation.x = -legSwing;
        if (leg2) leg2.rotation.x = -legSwing;
        if (leg3) leg3.rotation.x = legSwing;
      }
    }
  }

  // Damage mob
  public damageMob(mobId: string, damage: number): boolean {
    const mob = this.mobs.find(m => m.id === mobId);
    if (!mob) return false;

    mob.health -= damage;
    mob.isHurt = 0.3;
    this.sound.playHurt();

    // Knockback
    mob.vy = 3.5;
    mob.vx = -Math.sin(mob.yaw) * 3.0;
    mob.vz = -Math.cos(mob.yaw) * 3.0;

    // Death
    if (mob.health <= 0) {
      if (mob.type === 'pig') {
        this.spawnDroppedItem('item_porkchop', 1 + Math.floor(Math.random() * 2), mob.x, mob.y + 0.5, mob.z);
      } else if (mob.type === 'sheep') {
        this.spawnDroppedItem('block_dirt', 1, mob.x, mob.y + 0.5, mob.z);
      } else if (mob.type === 'zombie') {
        this.spawnDroppedItem('item_raw_iron', Math.random() < 0.25 ? 1 : 0, mob.x, mob.y + 0.5, mob.z);
      }
      this.spawnBlockBreakParticles(mob.x - 0.5, mob.y, mob.z - 0.5, 0xffffff, 20);
      this.scene.remove(mob.mesh);
      this.mobs = this.mobs.filter(m => m.id !== mobId);
      return true;
    }

    return false;
  }
}
