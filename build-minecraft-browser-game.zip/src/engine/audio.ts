export class SoundManager {
  private static instance: SoundManager;
  private ctx: AudioContext | null = null;
  public masterVolume: number = 0.5;
  public musicVolume: number = 0.3;
  private musicInterval: any = null;

  private constructor() {
    // AudioContext will be initialized on first user interaction
  }

  public static getInstance(): SoundManager {
    if (!SoundManager.instance) {
      SoundManager.instance = new SoundManager();
    }
    return SoundManager.instance;
  }

  private initContext() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioContextClass();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  // Play white/brown/pink noise burst for organic texture digging/breaking
  private playNoise(duration: number, filterFreq: number, filterType: BiquadFilterType = 'lowpass', gainVal: number = 1.0, pitch: number = 1.0) {
    this.initContext();
    if (!this.ctx) return;

    const bufferSize = this.ctx.sampleRate * duration;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);

    let lastOut = 0.0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      // Brown/Pink noise filtering
      data[i] = (lastOut + 0.02 * white) / 1.02;
      lastOut = data[i];
      data[i] *= 3.5; // boost
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;
    noise.playbackRate.value = pitch;

    const filter = this.ctx.createBiquadFilter();
    filter.type = filterType;
    filter.frequency.setValueAtTime(filterFreq, this.ctx.currentTime);

    const gain = this.ctx.createGain();
    const finalVolume = gainVal * this.masterVolume;
    gain.gain.setValueAtTime(finalVolume, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);

    noise.start();
  }

  // Block digging hit (clicking while mining)
  public playHit(soundType: 'grass' | 'dirt' | 'stone' | 'wood' | 'sand' | 'glass' | 'wool' = 'stone') {
    const pitch = 0.85 + Math.random() * 0.3;
    switch (soundType) {
      case 'grass':
      case 'wool':
        this.playNoise(0.08, 1200, 'lowpass', 0.4, pitch);
        break;
      case 'dirt':
        this.playNoise(0.09, 900, 'lowpass', 0.45, pitch);
        break;
      case 'wood':
        this.playTone(180 * pitch, 'triangle', 0.06, 0.3);
        this.playNoise(0.06, 800, 'bandpass', 0.3, pitch);
        break;
      case 'sand':
        this.playNoise(0.1, 700, 'lowpass', 0.35, pitch);
        break;
      case 'glass':
        this.playTone(1600 * pitch, 'sine', 0.05, 0.25);
        this.playNoise(0.05, 4000, 'highpass', 0.2, pitch);
        break;
      case 'stone':
      default:
        this.playNoise(0.08, 1800, 'bandpass', 0.4, pitch);
        this.playTone(120 * pitch, 'square', 0.03, 0.2);
        break;
    }
  }

  // Block break sound (satisfying crunch)
  public playBreak(soundType: 'grass' | 'dirt' | 'stone' | 'wood' | 'sand' | 'glass' | 'wool' = 'stone') {
    const pitch = 0.9 + Math.random() * 0.2;
    switch (soundType) {
      case 'grass':
      case 'wool':
        this.playNoise(0.2, 1400, 'lowpass', 0.6, pitch);
        break;
      case 'dirt':
        this.playNoise(0.22, 1000, 'lowpass', 0.65, pitch);
        break;
      case 'wood':
        this.playTone(220 * pitch, 'sawtooth', 0.12, 0.4);
        this.playNoise(0.18, 900, 'bandpass', 0.5, pitch);
        break;
      case 'sand':
        this.playNoise(0.22, 650, 'lowpass', 0.5, pitch);
        break;
      case 'glass':
        this.playTone(2200 * pitch, 'sine', 0.15, 0.5);
        this.playNoise(0.18, 5000, 'highpass', 0.4, pitch);
        break;
      case 'stone':
      default:
        this.playNoise(0.2, 2200, 'bandpass', 0.7, pitch);
        this.playTone(150 * pitch, 'triangle', 0.08, 0.3);
        break;
    }
  }

  // Block place sound (solid thud)
  public playPlace(soundType: 'grass' | 'dirt' | 'stone' | 'wood' | 'sand' | 'glass' | 'wool' = 'stone') {
    const pitch = 0.85 + Math.random() * 0.2;
    this.playTone(90 * pitch, 'triangle', 0.09, 0.4);
    this.playHit(soundType);
  }

  // Footstep sound
  public playStep(soundType: 'grass' | 'dirt' | 'stone' | 'wood' | 'sand' | 'glass' | 'wool' = 'stone') {
    const pitch = 0.9 + Math.random() * 0.25;
    switch (soundType) {
      case 'grass':
        this.playNoise(0.06, 900, 'lowpass', 0.22, pitch);
        break;
      case 'wood':
        this.playTone(140 * pitch, 'triangle', 0.05, 0.2);
        break;
      case 'sand':
        this.playNoise(0.08, 600, 'lowpass', 0.2, pitch);
        break;
      case 'stone':
      default:
        this.playNoise(0.05, 1400, 'bandpass', 0.25, pitch);
        break;
    }
  }

  // Item pickup "pop"
  public playPop() {
    this.initContext();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const now = this.ctx.currentTime;
    const startFreq = 300 + Math.random() * 100;
    osc.frequency.setValueAtTime(startFreq, now);
    osc.frequency.exponentialRampToValueAtTime(startFreq * 2.5, now + 0.08);

    gain.gain.setValueAtTime(0.35 * this.masterVolume, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.1);
  }

  // Jump sound
  public playJump() {
    this.initContext();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const now = this.ctx.currentTime;
    osc.frequency.setValueAtTime(120, now);
    osc.frequency.exponentialRampToValueAtTime(260, now + 0.12);

    gain.gain.setValueAtTime(0.2 * this.masterVolume, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.15);
  }

  // Water splash
  public playSplash() {
    this.playNoise(0.3, 1100, 'bandpass', 0.6, 0.9);
    this.playTone(280, 'sine', 0.2, 0.3);
  }

  // TNT fuse hiss
  public playFuse() {
    this.initContext();
    if (!this.ctx) return;
    this.playNoise(1.5, 3500, 'highpass', 0.35, 1.2);
  }

  // Huge TNT explosion!
  public playExplosion() {
    this.initContext();
    if (!this.ctx) return;
    // Deep sub bass
    this.playTone(65, 'sawtooth', 0.8, 0.8);
    // Huge noisy boom with lowpass filter sweep
    const duration = 1.6;
    const bufferSize = this.ctx.sampleRate * duration;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (this.ctx.sampleRate * 0.4));
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(1000, this.ctx.currentTime);
    filter.frequency.exponentialRampToValueAtTime(120, this.ctx.currentTime + duration);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(1.0 * this.masterVolume, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);
    noise.start();
  }

  // Hurt sound (classic oof!)
  public playHurt() {
    this.initContext();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const now = this.ctx.currentTime;
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(150, now);
    osc.frequency.exponentialRampToValueAtTime(80, now + 0.18);

    gain.gain.setValueAtTime(0.4 * this.masterVolume, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.2);
  }

  // Pig Oink
  public playPig() {
    this.initContext();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const now = this.ctx.currentTime;
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.linearRampToValueAtTime(420, now + 0.08);
    osc.frequency.linearRampToValueAtTime(280, now + 0.18);

    gain.gain.setValueAtTime(0.15 * this.masterVolume, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.2);
  }

  // Zombie Groan (eerie guttural growl)
  public playZombie() {
    this.initContext();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const now = this.ctx.currentTime;
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(75, now);
    osc.frequency.linearRampToValueAtTime(90, now + 0.3);
    osc.frequency.linearRampToValueAtTime(60, now + 0.8);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(400, now);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.2 * this.masterVolume, now + 0.2);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.9);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.9);
  }

  // Generic tone generator
  private playTone(freq: number, type: OscillatorType, duration: number, gainVal: number) {
    this.initContext();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const now = this.ctx.currentTime;
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);

    gain.gain.setValueAtTime(gainVal * this.masterVolume, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + duration);
  }

  // Ambient Minecraft-style calm piano synth (random C418-like melodic phrases!)
  public startAmbientMusic() {
    if (this.musicInterval) return;
    const notes = [261.63, 293.66, 329.63, 392.00, 440.00, 523.25, 659.25]; // C major pentatonic / calm

    const playAmbientChord = () => {
      this.initContext();
      if (!this.ctx || this.musicVolume <= 0) return;

      const baseNote = notes[Math.floor(Math.random() * notes.length)];
      const chord = [baseNote, baseNote * 1.25, baseNote * 1.5]; // major triad

      chord.forEach((freq, idx) => {
        setTimeout(() => {
          if (!this.ctx) return;
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          const now = this.ctx.currentTime;
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, now);

          gain.gain.setValueAtTime(0.001, now);
          gain.gain.linearRampToValueAtTime(0.1 * this.musicVolume, now + 0.8);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 4.0);

          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start(now);
          osc.stop(now + 4.2);
        }, idx * 300);
      });
    };

    // Play once soon, then every 25-45 seconds
    setTimeout(playAmbientChord, 3000);
    this.musicInterval = setInterval(() => {
      if (Math.random() > 0.3) {
        playAmbientChord();
      }
    }, 28000);
  }

  public stopAmbientMusic() {
    if (this.musicInterval) {
      clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
  }
}
