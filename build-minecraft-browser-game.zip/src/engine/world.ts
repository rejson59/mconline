import * as THREE from 'three';
import { BlockType } from '../types/game';
import { BLOCK_DEFS } from './blocks';
import { TextureManager } from './textures';
import { NoiseGenerator } from './noise';

export const CHUNK_SIZE_X = 16;
export const CHUNK_SIZE_Z = 16;
export const CHUNK_SIZE_Y = 64;
export const SEA_LEVEL = 20;

export interface RaycastResult {
  hit: boolean;
  block: BlockType;
  x: number;
  y: number;
  z: number;
  face: { x: number; y: number; z: number };
  placeX: number;
  placeY: number;
  placeZ: number;
  distance: number;
}

export class Chunk {
  public cx: number;
  public cz: number;
  public blocks: Uint8Array;
  public mesh: THREE.Mesh | null = null;
  public waterMesh: THREE.Mesh | null = null;
  public isDirty: boolean = true;
  public isGenerated: boolean = false;

  constructor(cx: number, cz: number) {
    this.cx = cx;
    this.cz = cz;
    this.blocks = new Uint8Array(CHUNK_SIZE_X * CHUNK_SIZE_Y * CHUNK_SIZE_Z);
  }

  public getIndex(x: number, y: number, z: number): number {
    return x + z * CHUNK_SIZE_X + y * CHUNK_SIZE_X * CHUNK_SIZE_Z;
  }

  public getBlock(x: number, y: number, z: number): BlockType {
    if (x < 0 || x >= CHUNK_SIZE_X || y < 0 || y >= CHUNK_SIZE_Y || z < 0 || z >= CHUNK_SIZE_Z) {
      return BlockType.AIR;
    }
    return this.blocks[this.getIndex(x, y, z)];
  }

  public setBlock(x: number, y: number, z: number, type: BlockType) {
    if (x < 0 || x >= CHUNK_SIZE_X || y < 0 || y >= CHUNK_SIZE_Y || z < 0 || z >= CHUNK_SIZE_Z) {
      return;
    }
    this.blocks[this.getIndex(x, y, z)] = type;
    this.isDirty = true;
  }
}

export class WorldManager {
  private chunks: Map<string, Chunk> = new Map();
  private scene: THREE.Scene;
  private noise: NoiseGenerator;
  private textureMgr: TextureManager;
  public solidMaterial!: THREE.MeshLambertMaterial;
  public transparentMaterial!: THREE.MeshLambertMaterial;
  public waterMaterial!: THREE.MeshLambertMaterial;
  public seed: number = 42;

  constructor(scene: THREE.Scene, seed: number = 42) {
    this.scene = scene;
    this.seed = seed;
    this.noise = new NoiseGenerator(seed);
    this.textureMgr = TextureManager.getInstance();
    this.initMaterials();
  }

  public setSeed(newSeed: number) {
    this.seed = newSeed;
    this.noise.reseed(newSeed);
    this.clearAll();
  }

  private initMaterials() {
    this.solidMaterial = new THREE.MeshLambertMaterial({
      map: this.textureMgr.atlasTexture,
      vertexColors: true,
      transparent: false,
      alphaTest: 0.1,
    });

    this.transparentMaterial = new THREE.MeshLambertMaterial({
      map: this.textureMgr.atlasTexture,
      vertexColors: true,
      transparent: true,
      alphaTest: 0.4,
      side: THREE.DoubleSide,
    });

    this.waterMaterial = new THREE.MeshLambertMaterial({
      map: this.textureMgr.atlasTexture,
      vertexColors: true,
      transparent: true,
      opacity: 0.65,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
  }

  private getChunkKey(cx: number, cz: number): string {
    return `${cx},${cz}`;
  }

  public getChunk(cx: number, cz: number): Chunk | undefined {
    return this.chunks.get(this.getChunkKey(cx, cz));
  }

  public getOrCreateChunk(cx: number, cz: number): Chunk {
    const key = this.getChunkKey(cx, cz);
    let chunk = this.chunks.get(key);
    if (!chunk) {
      chunk = new Chunk(cx, cz);
      this.chunks.set(key, chunk);
      this.generateChunkTerrain(chunk);
    }
    return chunk;
  }

  public getBlock(x: number, y: number, z: number): BlockType {
    if (y < 0 || y >= CHUNK_SIZE_Y) return BlockType.AIR;
    const cx = Math.floor(x / CHUNK_SIZE_X);
    const cz = Math.floor(z / CHUNK_SIZE_Z);
    const chunk = this.getChunk(cx, cz);
    if (!chunk) return BlockType.AIR;

    const lx = ((x % CHUNK_SIZE_X) + CHUNK_SIZE_X) % CHUNK_SIZE_X;
    const lz = ((z % CHUNK_SIZE_Z) + CHUNK_SIZE_Z) % CHUNK_SIZE_Z;
    return chunk.getBlock(lx, y, lz);
  }

  public setBlock(x: number, y: number, z: number, type: BlockType) {
    if (y < 0 || y >= CHUNK_SIZE_Y) return;
    const cx = Math.floor(x / CHUNK_SIZE_X);
    const cz = Math.floor(z / CHUNK_SIZE_Z);
    const chunk = this.getOrCreateChunk(cx, cz);

    const lx = ((x % CHUNK_SIZE_X) + CHUNK_SIZE_X) % CHUNK_SIZE_X;
    const lz = ((z % CHUNK_SIZE_Z) + CHUNK_SIZE_Z) % CHUNK_SIZE_Z;
    chunk.setBlock(lx, y, lz, type);

    // Check if on chunk border, mark neighbor dirty
    if (lx === 0) this.getChunk(cx - 1, cz)?.isDirty && (this.getChunk(cx - 1, cz)!.isDirty = true);
    if (lx === CHUNK_SIZE_X - 1) this.getChunk(cx + 1, cz)?.isDirty && (this.getChunk(cx + 1, cz)!.isDirty = true);
    if (lz === 0) this.getChunk(cx, cz - 1)?.isDirty && (this.getChunk(cx, cz - 1)!.isDirty = true);
    if (lz === CHUNK_SIZE_Z - 1) this.getChunk(cx, cz + 1)?.isDirty && (this.getChunk(cx, cz + 1)!.isDirty = true);
  }

  // Terrain generation
  private generateChunkTerrain(chunk: Chunk) {
    if (chunk.isGenerated) return;

    const treesToPlace: { lx: number; y: number; lz: number; type: 'oak' | 'birch' }[] = [];
    const flowersToPlace: { lx: number; y: number; lz: number; type: BlockType }[] = [];

    for (let lx = 0; lx < CHUNK_SIZE_X; lx++) {
      const wx = chunk.cx * CHUNK_SIZE_X + lx;
      for (let lz = 0; lz < CHUNK_SIZE_Z; lz++) {
        const wz = chunk.cz * CHUNK_SIZE_Z + lz;

        // Biome climate
        const temperature = (this.noise.noise2D(wx * 0.005 + 100, wz * 0.005 + 100) + 1) * 0.5; // 0 (cold) to 1 (hot)
        const moisture = (this.noise.noise2D(wx * 0.005 - 100, wz * 0.005 - 100) + 1) * 0.5; // 0 (dry) to 1 (wet)

        let isDesert = temperature > 0.65 && moisture < 0.35;
        let isSnow = temperature < 0.3;
        let isForest = !isDesert && !isSnow && moisture > 0.55;

        // Base elevation
        const baseHeight = 24;
        const elevation = this.noise.fractal2D(wx * 0.015, wz * 0.015, 4, 0.5, 2.0);
        const mountainFactor = Math.pow(Math.max(0, this.noise.noise2D(wx * 0.008, wz * 0.008)), 2) * 20;

        let surfaceHeight = Math.floor(baseHeight + elevation * 10 + mountainFactor);
        surfaceHeight = Math.max(3, Math.min(CHUNK_SIZE_Y - 8, surfaceHeight));

        // Generate column
        for (let y = 0; y < CHUNK_SIZE_Y; y++) {
          if (y === 0) {
            chunk.setBlock(lx, y, lz, BlockType.BEDROCK);
            continue;
          }

          if (y > surfaceHeight) {
            // Water layer
            if (y <= SEA_LEVEL) {
              chunk.setBlock(lx, y, lz, BlockType.WATER);
            }
            continue;
          }

          // 3D Cave carving
          const caveNoise = this.noise.fractal3D(wx * 0.04, y * 0.05, wz * 0.04, 3, 0.5, 2.0);
          if (caveNoise > 0.45 && y > 3 && y < surfaceHeight - 2) {
            continue; // carved cave
          }

          if (y === surfaceHeight) {
            if (y < SEA_LEVEL) {
              chunk.setBlock(lx, y, lz, BlockType.SAND);
            } else if (isDesert) {
              chunk.setBlock(lx, y, lz, BlockType.SAND);
            } else if (isSnow && y > 28) {
              chunk.setBlock(lx, y, lz, BlockType.SNOW_GRASS);
            } else {
              chunk.setBlock(lx, y, lz, BlockType.GRASS);
              // Opportunity for trees or flowers
              if (y > SEA_LEVEL) {
                const vegSeed = this.noise.noise2D(wx * 1.5, wz * 1.5);
                const treeChance = isForest ? 0.04 : 0.012;
                if (vegSeed > 0.4 && Math.random() < treeChance && lx >= 2 && lx <= 13 && lz >= 2 && lz <= 13) {
                  treesToPlace.push({ lx, y: y + 1, lz, type: isForest && Math.random() > 0.6 ? 'birch' : 'oak' });
                } else if (vegSeed < -0.3 && Math.random() < 0.08) {
                  flowersToPlace.push({ lx, y: y + 1, lz, type: Math.random() > 0.5 ? BlockType.FLOWER_RED : BlockType.FLOWER_YELLOW });
                }
              }
            }
          } else if (y >= surfaceHeight - 3) {
            if (isDesert) {
              chunk.setBlock(lx, y, lz, BlockType.SANDSTONE);
            } else {
              chunk.setBlock(lx, y, lz, BlockType.DIRT);
            }
          } else {
            // Stone strata with ore generation
            let block = BlockType.STONE;
            const oreRnd = Math.random();

            if (y < 14 && oreRnd < 0.012) {
              block = BlockType.DIAMOND_ORE;
            } else if (y < 16 && oreRnd < 0.02) {
              block = BlockType.REDSTONE_ORE;
            } else if (y < 24 && oreRnd < 0.02) {
              block = BlockType.GOLD_ORE;
            } else if (y < 35 && oreRnd < 0.04) {
              block = BlockType.IRON_ORE;
            } else if (oreRnd < 0.05) {
              block = BlockType.COAL_ORE;
            }

            chunk.setBlock(lx, y, lz, block);
          }
        }
      }
    }

    // Place trees
    for (const tree of treesToPlace) {
      const logType = tree.type === 'birch' ? BlockType.BIRCH_LOG : BlockType.OAK_LOG;
      const leafType = tree.type === 'birch' ? BlockType.BIRCH_LEAVES : BlockType.OAK_LEAVES;
      const trunkH = 4 + Math.floor(Math.random() * 3);

      for (let ty = 0; ty < trunkH; ty++) {
        if (tree.y + ty < CHUNK_SIZE_Y) {
          chunk.setBlock(tree.lx, tree.y + ty, tree.lz, logType);
        }
      }

      const leafStart = tree.y + trunkH - 2;
      for (let ly = leafStart; ly <= tree.y + trunkH + 1; ly++) {
        const radius = ly >= tree.y + trunkH ? 1 : 2;
        for (let dx = -radius; dx <= radius; dx++) {
          for (let dz = -radius; dz <= radius; dz++) {
            if (Math.abs(dx) === radius && Math.abs(dz) === radius && Math.random() > 0.5) continue;
            const targetX = tree.lx + dx;
            const targetZ = tree.lz + dz;
            if (targetX >= 0 && targetX < CHUNK_SIZE_X && targetZ >= 0 && targetZ < CHUNK_SIZE_Z && ly < CHUNK_SIZE_Y) {
              if (chunk.getBlock(targetX, ly, targetZ) === BlockType.AIR) {
                chunk.setBlock(targetX, ly, targetZ, leafType);
              }
            }
          }
        }
      }
    }

    // Place flowers
    for (const flower of flowersToPlace) {
      if (chunk.getBlock(flower.lx, flower.y, flower.lz) === BlockType.AIR) {
        chunk.setBlock(flower.lx, flower.y, flower.lz, flower.type);
      }
    }

    chunk.isGenerated = true;
    chunk.isDirty = true;
  }

  // Calculate Ambient Occlusion (AO) value for a vertex
  private calculateAO(side1: boolean, side2: boolean, corner: boolean): number {
    if (side1 && side2) {
      return 0; // complete occlusion
    }
    const val = (side1 ? 1 : 0) + (side2 ? 1 : 0) + (corner ? 1 : 0);
    return 3 - val; // 3 = full light, 0 = darkest
  }

  // Meshing: builds optimized geometry for a chunk
  public buildChunkMesh(chunk: Chunk) {
    if (!chunk.isDirty) return;

    // Remove existing meshes from scene
    if (chunk.mesh) {
      this.scene.remove(chunk.mesh);
      chunk.mesh.geometry.dispose();
      chunk.mesh = null;
    }
    if (chunk.waterMesh) {
      this.scene.remove(chunk.waterMesh);
      chunk.waterMesh.geometry.dispose();
      chunk.waterMesh = null;
    }

    const solidPositions: number[] = [];
    const solidNormals: number[] = [];
    const solidUvs: number[] = [];
    const solidColors: number[] = [];

    const waterPositions: number[] = [];
    const waterNormals: number[] = [];
    const waterUvs: number[] = [];
    const waterColors: number[] = [];

    const aoLevels = [0.45, 0.65, 0.85, 1.0];

    const isSolidOpaque = (b: BlockType): boolean => {
      if (b === BlockType.AIR) return false;
      const def = BLOCK_DEFS[b];
      return !def.transparent && !def.isLiquid && !def.isPlant;
    };

    const isBlockTransparent = (b: BlockType): boolean => {
      if (b === BlockType.AIR) return true;
      const def = BLOCK_DEFS[b];
      return !!def.transparent || !!def.isLiquid;
    };

    const isLiquidBlock = (b: BlockType): boolean => {
      return b === BlockType.WATER;
    };

    const faces = [
      // Right (+X)
      { dir: [1, 0, 0], light: 0.75, uvs: [0, 1],
        corners: [[1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 0, 1]],
        aoOffsets: [
          [[1, 0, -1], [1, -1, 0], [1, -1, -1]],
          [[1, 0, -1], [1, 1, 0], [1, 1, -1]],
          [[1, 0, 1], [1, 1, 0], [1, 1, 1]],
          [[1, 0, 1], [1, -1, 0], [1, -1, 1]]
        ]
      },
      // Left (-X)
      { dir: [-1, 0, 0], light: 0.75,
        corners: [[0, 0, 1], [0, 1, 1], [0, 1, 0], [0, 0, 0]],
        aoOffsets: [
          [[-1, 0, 1], [-1, -1, 0], [-1, -1, 1]],
          [[-1, 0, 1], [-1, 1, 0], [-1, 1, 1]],
          [[-1, 0, -1], [-1, 1, 0], [-1, 1, -1]],
          [[-1, 0, -1], [-1, -1, 0], [-1, -1, -1]]
        ]
      },
      // Top (+Y)
      { dir: [0, 1, 0], light: 1.0,
        corners: [[0, 1, 1], [1, 1, 1], [1, 1, 0], [0, 1, 0]],
        aoOffsets: [
          [[-1, 1, 0], [0, 1, 1], [-1, 1, 1]],
          [[1, 1, 0], [0, 1, 1], [1, 1, 1]],
          [[1, 1, 0], [0, 1, -1], [1, 1, -1]],
          [[-1, 1, 0], [0, 1, -1], [-1, 1, -1]]
        ]
      },
      // Bottom (-Y)
      { dir: [0, -1, 0], light: 0.5,
        corners: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]],
        aoOffsets: [
          [[-1, -1, 0], [0, -1, -1], [-1, -1, -1]],
          [[1, -1, 0], [0, -1, -1], [1, -1, -1]],
          [[1, -1, 0], [0, -1, 1], [1, -1, 1]],
          [[-1, -1, 0], [0, -1, 1], [-1, -1, 1]]
        ]
      },
      // Front (+Z)
      { dir: [0, 0, 1], light: 0.85,
        corners: [[1, 0, 1], [1, 1, 1], [0, 1, 1], [0, 0, 1]],
        aoOffsets: [
          [[1, 0, 1], [0, -1, 1], [1, -1, 1]],
          [[1, 0, 1], [0, 1, 1], [1, 1, 1]],
          [[-1, 0, 1], [0, 1, 1], [-1, 1, 1]],
          [[-1, 0, 1], [0, -1, 1], [-1, -1, 1]]
        ]
      },
      // Back (-Z)
      { dir: [0, 0, -1], light: 0.85,
        corners: [[0, 0, 0], [0, 1, 0], [1, 1, 0], [1, 0, 0]],
        aoOffsets: [
          [[-1, 0, -1], [0, -1, -1], [-1, -1, -1]],
          [[-1, 0, -1], [0, 1, -1], [-1, 1, -1]],
          [[1, 0, -1], [0, 1, -1], [1, 1, -1]],
          [[1, 0, -1], [0, -1, -1], [1, -1, -1]]
        ]
      },
    ];

    const worldX0 = chunk.cx * CHUNK_SIZE_X;
    const worldZ0 = chunk.cz * CHUNK_SIZE_Z;

    for (let lx = 0; lx < CHUNK_SIZE_X; lx++) {
      const wx = worldX0 + lx;
      for (let lz = 0; lz < CHUNK_SIZE_Z; lz++) {
        const wz = worldZ0 + lz;
        for (let y = 0; y < CHUNK_SIZE_Y; y++) {
          const block = chunk.getBlock(lx, y, lz);
          if (block === BlockType.AIR) continue;

          const def = BLOCK_DEFS[block];
          if (!def) continue;

          const isWater = block === BlockType.WATER;

          // Cross-quad rendering for flowers/plants
          if (def.isPlant) {
            const uv = this.textureMgr.getUV(def.topTexture);
            const plantQuads = [
              // Diagonal 1
              [[0.15, 0, 0.15], [0.85, 0, 0.85], [0.85, 1, 0.85], [0.15, 1, 0.15]],
              [[0.85, 0, 0.85], [0.15, 0, 0.15], [0.15, 1, 0.15], [0.85, 1, 0.85]],
              // Diagonal 2
              [[0.15, 0, 0.85], [0.85, 0, 0.15], [0.85, 1, 0.15], [0.15, 1, 0.85]],
              [[0.85, 0, 0.15], [0.15, 0, 0.85], [0.15, 1, 0.85], [0.85, 1, 0.15]]
            ];

            for (const q of plantQuads) {
              const [c0, c1, c2, c3] = q;
              const idxs = [0, 1, 2, 0, 2, 3];
              const quadVerts = [c0, c1, c2, c3];
              const uvsList = [
                [uv[0], uv[1]], [uv[2], uv[1]], [uv[2], uv[3]], [uv[0], uv[3]]
              ];

              for (const i of idxs) {
                solidPositions.push(wx + quadVerts[i][0], y + quadVerts[i][1], wz + quadVerts[i][2]);
                solidNormals.push(0, 1, 0);
                solidUvs.push(uvsList[i][0], uvsList[i][1]);
                solidColors.push(1.0, 1.0, 1.0);
              }
            }
            continue;
          }

          // 6 Faces
          for (let fIdx = 0; fIdx < faces.length; fIdx++) {
            const face = faces[fIdx];
            const nx = wx + face.dir[0];
            const ny = y + face.dir[1];
            const nz = wz + face.dir[2];

            const neighbor = this.getBlock(nx, ny, nz);

            // Culling condition:
            let shouldRender = false;
            if (isWater) {
              // Water only renders against air or different transparent block (not water)
              shouldRender = neighbor === BlockType.AIR || (!isLiquidBlock(neighbor) && isBlockTransparent(neighbor));
            } else if (def.transparent) {
              // Transparent block (glass, leaves) renders if neighbor is air or different block
              shouldRender = neighbor !== block;
            } else {
              // Solid block renders if neighbor is transparent or air
              shouldRender = isBlockTransparent(neighbor);
            }

            if (!shouldRender) continue;

            // Pick correct texture
            let texName = def.sideTexture;
            if (face.dir[1] === 1) {
              texName = def.topTexture;
            } else if (face.dir[1] === -1) {
              texName = def.bottomTexture;
            } else if (face.dir[2] === 1 && def.frontTexture) {
              texName = def.frontTexture;
            }

            const uv = this.textureMgr.getUV(texName);

            // Compute AO for each of 4 corners of face
            const cornerAo: number[] = [3, 3, 3, 3];
            if (!isWater && !def.isPlant) {
              for (let c = 0; c < 4; c++) {
                const [o1, o2, o3] = face.aoOffsets[c];
                const s1 = isSolidOpaque(this.getBlock(wx + o1[0], y + o1[1], wz + o1[2]));
                const s2 = isSolidOpaque(this.getBlock(wx + o2[0], y + o2[1], wz + o2[2]));
                const cornerBlock = isSolidOpaque(this.getBlock(wx + o3[0], y + o3[1], wz + o3[2]));
                cornerAo[c] = this.calculateAO(s1, s2, cornerBlock);
              }
            }

            const lightBase = face.light;
            const targetPositions = isWater ? waterPositions : solidPositions;
            const targetNormals = isWater ? waterNormals : solidNormals;
            const targetUvs = isWater ? waterUvs : solidUvs;
            const targetColors = isWater ? waterColors : solidColors;

            // 2 Triangles per quad
            // Vertices 0, 1, 2 and 0, 2, 3
            // If AO is flip-dependent, we flip triangles to prevent anisotropic seam
            const flip = cornerAo[0] + cornerAo[2] > cornerAo[1] + cornerAo[3];
            const indices = flip ? [1, 2, 3, 1, 3, 0] : [0, 1, 2, 0, 2, 3];

            const cUv = [
              [uv[0], uv[1]],
              [uv[2], uv[1]],
              [uv[2], uv[3]],
              [uv[0], uv[3]]
            ];

            for (const idx of indices) {
              const pt = face.corners[idx];
              targetPositions.push(wx + pt[0], y + (isWater && face.dir[1] === 1 ? pt[1] - 0.12 : pt[1]), wz + pt[2]);
              targetNormals.push(face.dir[0], face.dir[1], face.dir[2]);
              targetUvs.push(cUv[idx][0], cUv[idx][1]);

              const aoMult = aoLevels[cornerAo[idx]];
              const finalR = lightBase * aoMult;
              const finalG = lightBase * aoMult;
              const finalB = lightBase * aoMult;

              targetColors.push(finalR, finalG, finalB);
            }
          }
        }
      }
    }

    // Build solid geometry
    if (solidPositions.length > 0) {
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(solidPositions, 3));
      geo.setAttribute('normal', new THREE.Float32BufferAttribute(solidNormals, 3));
      geo.setAttribute('uv', new THREE.Float32BufferAttribute(solidUvs, 2));
      geo.setAttribute('color', new THREE.Float32BufferAttribute(solidColors, 3));

      const mesh = new THREE.Mesh(geo, this.solidMaterial);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      this.scene.add(mesh);
      chunk.mesh = mesh;
    }

    // Build water geometry
    if (waterPositions.length > 0) {
      const waterGeo = new THREE.BufferGeometry();
      waterGeo.setAttribute('position', new THREE.Float32BufferAttribute(waterPositions, 3));
      waterGeo.setAttribute('normal', new THREE.Float32BufferAttribute(waterNormals, 3));
      waterGeo.setAttribute('uv', new THREE.Float32BufferAttribute(waterUvs, 2));
      waterGeo.setAttribute('color', new THREE.Float32BufferAttribute(waterColors, 3));

      const waterMesh = new THREE.Mesh(waterGeo, this.waterMaterial);
      this.scene.add(waterMesh);
      chunk.waterMesh = waterMesh;
    }

    chunk.isDirty = false;
  }

  // Update chunks around player position
  public update(playerX: number, playerZ: number, renderDistance: number) {
    const pChunkX = Math.floor(playerX / CHUNK_SIZE_X);
    const pChunkZ = Math.floor(playerZ / CHUNK_SIZE_Z);

    const neededKeys = new Set<string>();

    for (let dx = -renderDistance; dx <= renderDistance; dx++) {
      for (let dz = -renderDistance; dz <= renderDistance; dz++) {
        if (dx * dx + dz * dz > (renderDistance + 0.5) * (renderDistance + 0.5)) continue;
        const cx = pChunkX + dx;
        const cz = pChunkZ + dz;
        const key = this.getChunkKey(cx, cz);
        neededKeys.add(key);

        const chunk = this.getOrCreateChunk(cx, cz);
        if (chunk.isDirty) {
          this.buildChunkMesh(chunk);
        }
      }
    }

    // Unload distant chunks to preserve high frame rate
    for (const [key, chunk] of this.chunks.entries()) {
      if (!neededKeys.has(key)) {
        if (chunk.mesh) {
          this.scene.remove(chunk.mesh);
          chunk.mesh.geometry.dispose();
          chunk.mesh = null;
        }
        if (chunk.waterMesh) {
          this.scene.remove(chunk.waterMesh);
          chunk.waterMesh.geometry.dispose();
          chunk.waterMesh = null;
        }
        chunk.isDirty = true;
      }
    }
  }

  // Fast voxel raycast using Amanatides-Woo Grid Traversal
  public raycast(origin: THREE.Vector3, direction: THREE.Vector3, maxDistance: number = 6): RaycastResult | null {
    let x = Math.floor(origin.x);
    let y = Math.floor(origin.y);
    let z = Math.floor(origin.z);

    const stepX = Math.sign(direction.x);
    const stepY = Math.sign(direction.y);
    const stepZ = Math.sign(direction.z);

    const tDeltaX = direction.x !== 0 ? Math.abs(1 / direction.x) : Infinity;
    const tDeltaY = direction.y !== 0 ? Math.abs(1 / direction.y) : Infinity;
    const tDeltaZ = direction.z !== 0 ? Math.abs(1 / direction.z) : Infinity;

    let tMaxX = direction.x > 0 ? (x + 1 - origin.x) * tDeltaX : (origin.x - x) * tDeltaX;
    let tMaxY = direction.y > 0 ? (y + 1 - origin.y) * tDeltaY : (origin.y - y) * tDeltaY;
    let tMaxZ = direction.z > 0 ? (z + 1 - origin.z) * tDeltaZ : (origin.z - z) * tDeltaZ;

    let faceX = 0, faceY = 0, faceZ = 0;
    let distance = 0;

    while (distance <= maxDistance) {
      const block = this.getBlock(x, y, z);
      if (block !== BlockType.AIR && block !== BlockType.WATER) {
        return {
          hit: true,
          block,
          x,
          y,
          z,
          face: { x: faceX, y: faceY, z: faceZ },
          placeX: x + faceX,
          placeY: y + faceY,
          placeZ: z + faceZ,
          distance
        };
      }

      if (tMaxX < tMaxY) {
        if (tMaxX < tMaxZ) {
          x += stepX;
          distance = tMaxX;
          tMaxX += tDeltaX;
          faceX = -stepX;
          faceY = 0;
          faceZ = 0;
        } else {
          z += stepZ;
          distance = tMaxZ;
          tMaxZ += tDeltaZ;
          faceX = 0;
          faceY = 0;
          faceZ = -stepZ;
        }
      } else {
        if (tMaxY < tMaxZ) {
          y += stepY;
          distance = tMaxY;
          tMaxY += tDeltaY;
          faceX = 0;
          faceY = -stepY;
          faceZ = 0;
        } else {
          z += stepZ;
          distance = tMaxZ;
          tMaxZ += tDeltaZ;
          faceX = 0;
          faceY = 0;
          faceZ = -stepZ;
        }
      }
    }

    return null;
  }

  // Clear all chunks
  public clearAll() {
    for (const chunk of this.chunks.values()) {
      if (chunk.mesh) {
        this.scene.remove(chunk.mesh);
        chunk.mesh.geometry.dispose();
      }
      if (chunk.waterMesh) {
        this.scene.remove(chunk.waterMesh);
        chunk.waterMesh.geometry.dispose();
      }
    }
    this.chunks.clear();
  }
}
