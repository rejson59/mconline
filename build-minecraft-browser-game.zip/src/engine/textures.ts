import * as THREE from 'three';

export interface TextureMap {
  [name: string]: number; // index in atlas
}

export class TextureManager {
  private static instance: TextureManager;
  public atlasTexture!: THREE.CanvasTexture;
  public waterTexture!: THREE.CanvasTexture;
  public crackTextures: THREE.CanvasTexture[] = [];
  public itemIcons: Record<string, string> = {}; // data URLs for 2D UI
  public textureIndices: Record<string, number> = {};
  public tileSize: number = 32; // 32x32 per block texture for ultra-crisp HD pixel look!
  public atlasTilesX: number = 16;
  public atlasTilesY: number = 16;

  private constructor() {
    this.generateAtlas();
    this.generateCracks();
  }

  public static getInstance(): TextureManager {
    if (!TextureManager.instance) {
      TextureManager.instance = new TextureManager();
    }
    return TextureManager.instance;
  }

  private generateAtlas() {
    const canvas = document.createElement('canvas');
    const S = this.tileSize;
    canvas.width = this.atlasTilesX * S;
    canvas.height = this.atlasTilesY * S;
    const ctx = canvas.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;

    // Fill background transparent
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    let currentIndex = 0;
    const register = (name: string, painter: (ctx: CanvasRenderingContext2D, x: number, y: number, s: number) => void) => {
      const tileX = currentIndex % this.atlasTilesX;
      const tileY = Math.floor(currentIndex / this.atlasTilesX);
      const px = tileX * S;
      const py = tileY * S;

      ctx.save();
      painter(ctx, px, py, S);
      ctx.restore();

      this.textureIndices[name] = currentIndex;

      // Also create high-res icon data URL for UI
      const iconCanvas = document.createElement('canvas');
      iconCanvas.width = S;
      iconCanvas.height = S;
      const ictx = iconCanvas.getContext('2d')!;
      ictx.imageSmoothingEnabled = false;
      ictx.drawImage(canvas, px, py, S, S, 0, 0, S, S);
      this.itemIcons[name] = iconCanvas.toDataURL('image/png');

      currentIndex++;
    };

    // Helper random noise
    const seedNoise = (x: number, y: number) => {
      const n = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453;
      return n - Math.floor(n);
    };

    // 1. Dirt
    register('dirt', (c, x, y, s) => {
      c.fillStyle = '#866043';
      c.fillRect(x, y, s, s);
      for (let py = 0; py < s; py += 2) {
        for (let px = 0; px < s; px += 2) {
          const r = seedNoise(x + px, y + py);
          if (r > 0.7) c.fillStyle = '#6b4c35';
          else if (r > 0.4) c.fillStyle = '#9c7250';
          else if (r > 0.2) c.fillStyle = '#7a553a';
          else c.fillStyle = '#593d26';
          c.fillRect(x + px, y + py, 2, 2);
        }
      }
    });

    // 2. Grass Top
    register('grass_top', (c, x, y, s) => {
      c.fillStyle = '#56a737';
      c.fillRect(x, y, s, s);
      for (let py = 0; py < s; py += 2) {
        for (let px = 0; px < s; px += 2) {
          const r = seedNoise(x + px, y + py);
          if (r > 0.75) c.fillStyle = '#68c442';
          else if (r > 0.5) c.fillStyle = '#4c9630';
          else if (r > 0.25) c.fillStyle = '#3c7926';
          else c.fillStyle = '#5fb53c';
          c.fillRect(x + px, y + py, 2, 2);
        }
      }
    });

    // 3. Grass Side
    register('grass_side', (c, x, y, s) => {
      // Base dirt
      c.fillStyle = '#866043';
      c.fillRect(x, y, s, s);
      for (let py = 0; py < s; py += 2) {
        for (let px = 0; px < s; px += 2) {
          const r = seedNoise(x + px, y + py);
          c.fillStyle = r > 0.5 ? '#7a553a' : '#9c7250';
          c.fillRect(x + px, y + py, 2, 2);
        }
      }
      // Grass top overhang
      c.fillStyle = '#56a737';
      c.fillRect(x, y, s, 6);
      for (let px = 0; px < s; px += 2) {
        const drop = Math.floor(seedNoise(x + px, y) * 8) + 2;
        c.fillStyle = seedNoise(x + px, y + 1) > 0.5 ? '#4c9630' : '#68c442';
        c.fillRect(x + px, y, 2, drop);
      }
    });

    // 4. Stone
    register('stone', (c, x, y, s) => {
      c.fillStyle = '#7d7d7d';
      c.fillRect(x, y, s, s);
      for (let py = 0; py < s; py += 2) {
        for (let px = 0; px < s; px += 2) {
          const r = seedNoise(x + px, y + py);
          if (r > 0.8) c.fillStyle = '#616161';
          else if (r > 0.6) c.fillStyle = '#949494';
          else if (r > 0.3) c.fillStyle = '#737373';
          else c.fillStyle = '#878787';
          c.fillRect(x + px, y + py, 2, 2);
        }
      }
    });

    // 5. Cobblestone
    register('cobblestone', (c, x, y, s) => {
      c.fillStyle = '#525252';
      c.fillRect(x, y, s, s);
      // Irregular stone clumps
      const stones = [
        [2, 2, 12, 10], [16, 2, 14, 8],
        [2, 14, 14, 8], [18, 12, 12, 10],
        [4, 24, 12, 6], [18, 24, 12, 6]
      ];
      stones.forEach(([sx, sy, sw, sh]) => {
        c.fillStyle = '#8a8a8a';
        c.fillRect(x + sx, y + sy, sw, sh);
        c.fillStyle = '#a1a1a1';
        c.fillRect(x + sx + 2, y + sy + 2, sw - 4, sh - 4);
        c.fillStyle = '#636363';
        c.fillRect(x + sx + sw - 2, y + sy + 2, 2, sh - 2);
      });
    });

    // 6. Oak Log Side
    register('log_oak', (c, x, y, s) => {
      c.fillStyle = '#675232';
      c.fillRect(x, y, s, s);
      // Vertical bark grooves
      for (let px = 0; px < s; px += 4) {
        c.fillStyle = '#4c3b24';
        c.fillRect(x + px, y, 2, s);
        c.fillStyle = '#7a623c';
        c.fillRect(x + px + 2, y, 2, s);
      }
    });

    // 7. Oak Log Top
    register('log_oak_top', (c, x, y, s) => {
      c.fillStyle = '#9d7f4e';
      c.fillRect(x, y, s, s);
      // Rings
      c.strokeStyle = '#675232';
      c.lineWidth = 2;
      c.strokeRect(x + 2, y + 2, s - 4, s - 4);
      c.strokeStyle = '#7c653f';
      c.strokeRect(x + 6, y + 6, s - 12, s - 12);
      c.strokeStyle = '#5a4629';
      c.strokeRect(x + 10, y + 10, s - 20, s - 20);
      c.fillStyle = '#503e24';
      c.fillRect(x + s/2 - 2, y + s/2 - 2, 4, 4);
    });

    // 8. Oak Planks
    register('planks_oak', (c, x, y, s) => {
      c.fillStyle = '#b8945f';
      c.fillRect(x, y, s, s);
      const rowH = s / 4;
      for (let r = 0; r < 4; r++) {
        const ry = y + r * rowH;
        c.fillStyle = '#886738';
        c.fillRect(x, ry, s, 2); // horizontal line
        // plank grain
        for (let px = 0; px < s; px += 2) {
          const v = seedNoise(x + px, ry);
          c.fillStyle = v > 0.6 ? '#c7a36c' : v > 0.3 ? '#b08b55' : '#9f7b47';
          c.fillRect(x + px, ry + 2, 2, rowH - 2);
        }
        // Vertical seam
        const seamX = (r % 2 === 0) ? x + s / 2 : x + s / 4;
        c.fillStyle = '#614824';
        c.fillRect(seamX, ry, 2, rowH);
      }
    });

    // 9. Oak Leaves
    register('leaves_oak', (c, x, y, s) => {
      c.fillStyle = '#2e6b1d';
      c.fillRect(x, y, s, s);
      for (let py = 0; py < s; py += 2) {
        for (let px = 0; px < s; px += 2) {
          const r = seedNoise(x + px, y + py);
          if (r > 0.8) {
            c.clearRect(x + px, y + py, 2, 2); // see-through pixel!
          } else if (r > 0.5) {
            c.fillStyle = '#448b2c';
            c.fillRect(x + px, y + py, 2, 2);
          } else if (r > 0.3) {
            c.fillStyle = '#225514';
            c.fillRect(x + px, y + py, 2, 2);
          } else {
            c.fillStyle = '#367923';
            c.fillRect(x + px, y + py, 2, 2);
          }
        }
      }
    });

    // 10. Sand
    register('sand', (c, x, y, s) => {
      c.fillStyle = '#dbce9b';
      c.fillRect(x, y, s, s);
      for (let py = 0; py < s; py += 2) {
        for (let px = 0; px < s; px += 2) {
          const r = seedNoise(x + px, y + py);
          c.fillStyle = r > 0.6 ? '#e8dcab' : r > 0.3 ? '#cfc189' : '#bdad75';
          c.fillRect(x + px, y + py, 2, 2);
        }
      }
    });

    // 11. Sandstone Side
    register('sandstone_side', (c, x, y, s) => {
      c.fillStyle = '#ded5a6';
      c.fillRect(x, y, s, s);
      c.fillStyle = '#c9be8b';
      c.fillRect(x, y + s - 8, s, 8);
      // subtle layered bands
      c.fillStyle = '#baa972';
      c.fillRect(x, y + 10, s, 2);
      c.fillRect(x, y + 20, s, 2);
    });

    // 12. Sandstone Top
    register('sandstone_top', (c, x, y, s) => {
      c.fillStyle = '#e8dfb5';
      c.fillRect(x, y, s, s);
      c.strokeStyle = '#c9be8b';
      c.strokeRect(x + 4, y + 4, s - 8, s - 8);
    });

    // 13. Sandstone Bottom
    register('sandstone_bottom', (c, x, y, s) => {
      c.fillStyle = '#cfc189';
      c.fillRect(x, y, s, s);
    });

    // 14. Glass
    register('glass', (c, x, y, s) => {
      c.clearRect(x, y, s, s);
      c.fillStyle = 'rgba(255, 255, 255, 0.6)';
      // Border
      c.fillRect(x, y, s, 2);
      c.fillRect(x, y + s - 2, s, 2);
      c.fillRect(x, y, 2, s);
      c.fillRect(x + s - 2, y, 2, s);
      // Glint streaks
      c.fillRect(x + 4, y + 4, 4, 2);
      c.fillRect(x + 6, y + 6, 2, 4);
      c.fillRect(x + 20, y + 18, 6, 2);
    });

    // 15. Water
    register('water', (c, x, y, s) => {
      c.fillStyle = 'rgba(38, 92, 219, 0.7)';
      c.fillRect(x, y, s, s);
      for (let py = 0; py < s; py += 4) {
        c.fillStyle = 'rgba(64, 120, 245, 0.6)';
        c.fillRect(x, y + py, s, 2);
      }
    });

    // 16. Bedrock
    register('bedrock', (c, x, y, s) => {
      c.fillStyle = '#1c1c1c';
      c.fillRect(x, y, s, s);
      for (let py = 0; py < s; py += 2) {
        for (let px = 0; px < s; px += 2) {
          const r = seedNoise(x + px, y + py);
          c.fillStyle = r > 0.7 ? '#424242' : r > 0.4 ? '#2b2b2b' : '#111111';
          c.fillRect(x + px, y + py, 2, 2);
        }
      }
    });

    // 17. Coal Ore
    register('coal_ore', (c, x, y, s) => {
      // stone base
      c.fillStyle = '#7d7d7d';
      c.fillRect(x, y, s, s);
      for (let py = 0; py < s; py += 2) {
        for (let px = 0; px < s; px += 2) {
          if (seedNoise(x + px, y + py) > 0.5) {
            c.fillStyle = '#878787';
            c.fillRect(x + px, y + py, 2, 2);
          }
        }
      }
      // coal patches
      const patches = [[6, 6, 6, 6], [18, 8, 8, 6], [8, 18, 7, 7], [20, 20, 6, 6]];
      patches.forEach(([px, py, pw, ph]) => {
        c.fillStyle = '#1e1e1e';
        c.fillRect(x + px, y + py, pw, ph);
        c.fillStyle = '#363636';
        c.fillRect(x + px + 2, y + py + 2, pw - 3, ph - 3);
      });
    });

    // 18. Iron Ore
    register('iron_ore', (c, x, y, s) => {
      c.fillStyle = '#7d7d7d';
      c.fillRect(x, y, s, s);
      const patches = [[8, 6, 6, 5], [16, 12, 7, 6], [6, 20, 7, 6], [22, 22, 5, 5]];
      patches.forEach(([px, py, pw, ph]) => {
        c.fillStyle = '#9e8574';
        c.fillRect(x + px, y + py, pw, ph);
        c.fillStyle = '#d4beaa';
        c.fillRect(x + px + 1, y + py + 1, pw - 2, ph - 2);
      });
    });

    // 19. Gold Ore
    register('gold_ore', (c, x, y, s) => {
      c.fillStyle = '#7d7d7d';
      c.fillRect(x, y, s, s);
      const patches = [[8, 8, 6, 5], [18, 10, 6, 6], [10, 20, 8, 5], [20, 22, 6, 5]];
      patches.forEach(([px, py, pw, ph]) => {
        c.fillStyle = '#ca9c1b';
        c.fillRect(x + px, y + py, pw, ph);
        c.fillStyle = '#ffdf43';
        c.fillRect(x + px + 1, y + py + 1, pw - 2, ph - 2);
      });
    });

    // 20. Diamond Ore
    register('diamond_ore', (c, x, y, s) => {
      c.fillStyle = '#7d7d7d';
      c.fillRect(x, y, s, s);
      const patches = [[6, 8, 6, 6], [18, 6, 6, 5], [8, 18, 7, 6], [20, 18, 7, 7]];
      patches.forEach(([px, py, pw, ph]) => {
        c.fillStyle = '#269199';
        c.fillRect(x + px, y + py, pw, ph);
        c.fillStyle = '#5bf0e8';
        c.fillRect(x + px + 1, y + py + 1, pw - 2, ph - 2);
        c.fillStyle = '#ffffff';
        c.fillRect(x + px + 2, y + py + 2, 2, 2);
      });
    });

    // 21. Redstone Ore
    register('redstone_ore', (c, x, y, s) => {
      c.fillStyle = '#7d7d7d';
      c.fillRect(x, y, s, s);
      const patches = [[8, 6, 6, 5], [18, 12, 7, 6], [6, 20, 7, 6], [20, 20, 6, 6]];
      patches.forEach(([px, py, pw, ph]) => {
        c.fillStyle = '#9b1b1b';
        c.fillRect(x + px, y + py, pw, ph);
        c.fillStyle = '#e82b2b';
        c.fillRect(x + px + 1, y + py + 1, pw - 2, ph - 2);
      });
    });

    // 22. Bricks
    register('bricks', (c, x, y, s) => {
      c.fillStyle = '#b7b4b1'; // mortar
      c.fillRect(x, y, s, s);
      const rowH = 8;
      for (let r = 0; r < 4; r++) {
        const ry = y + r * rowH;
        const shift = (r % 2 === 0) ? 0 : 8;
        for (let bx = -8; bx < s + 8; bx += 16) {
          c.fillStyle = '#964835';
          c.fillRect(x + bx + shift + 1, ry + 1, 14, 6);
          c.fillStyle = '#b15a44';
          c.fillRect(x + bx + shift + 2, ry + 2, 12, 4);
        }
      }
    });

    // 23. Bookshelf
    register('bookshelf', (c, x, y, s) => {
      // wood frame
      c.fillStyle = '#b8945f';
      c.fillRect(x, y, s, s);
      // 2 interior shelves
      c.fillStyle = '#3f2d18';
      c.fillRect(x + 2, y + 2, s - 4, 12);
      c.fillRect(x + 2, y + 18, s - 4, 12);
      // book spines
      const colors = ['#aa3333', '#338833', '#3333aa', '#aa8833', '#555555'];
      for (let sh = 0; sh < 2; sh++) {
        const sy = sh === 0 ? y + 3 : y + 19;
        let bx = x + 3;
        while (bx < x + s - 4) {
          const bw = Math.min(4 + Math.floor(seedNoise(bx, sy) * 3), x + s - 4 - bx);
          c.fillStyle = colors[Math.floor(seedNoise(bx + 1, sy) * colors.length)];
          c.fillRect(bx, sy, bw, 10);
          c.fillStyle = '#ffffff';
          c.fillRect(bx + 1, sy + 3, bw - 2, 2);
          bx += bw + 1;
        }
      }
    });

    // 24. TNT Top
    register('tnt_top', (c, x, y, s) => {
      c.fillStyle = '#c73322';
      c.fillRect(x, y, s, s);
      c.fillStyle = '#dedede';
      c.fillRect(x + 8, y + 8, s - 16, s - 16);
      c.fillStyle = '#222222';
      c.fillRect(x + s/2 - 2, y + s/2 - 2, 4, 4);
    });

    // 25. TNT Side
    register('tnt_side', (c, x, y, s) => {
      c.fillStyle = '#c73322';
      c.fillRect(x, y, s, s);
      // Sticks vertical stripes
      for (let px = 0; px < s; px += 4) {
        c.fillStyle = '#9c2518';
        c.fillRect(x + px, y, 1, s);
      }
      // White middle banner
      c.fillStyle = '#eeeeee';
      c.fillRect(x, y + 10, s, 12);
      // TNT Text
      c.fillStyle = '#111111';
      c.font = 'bold 9px monospace';
      c.fillText('TNT', x + 5, y + 19);
    });

    // 26. TNT Bottom
    register('tnt_bottom', (c, x, y, s) => {
      c.fillStyle = '#9c2518';
      c.fillRect(x, y, s, s);
    });

    // 27. Torch
    register('torch', (c, x, y, s) => {
      c.clearRect(x, y, s, s);
      // Wood stick
      c.fillStyle = '#866043';
      c.fillRect(x + 14, y + 10, 4, 18);
      // Coal head
      c.fillStyle = '#333333';
      c.fillRect(x + 14, y + 8, 4, 4);
      // Flame
      c.fillStyle = '#ffaa00';
      c.fillRect(x + 13, y + 4, 6, 6);
      c.fillStyle = '#ffff55';
      c.fillRect(x + 14, y + 5, 4, 4);
    });

    // 28. Crafting Table Top
    register('crafting_table_top', (c, x, y, s) => {
      c.fillStyle = '#986b3e';
      c.fillRect(x, y, s, s);
      c.strokeStyle = '#5a3d1c';
      c.lineWidth = 2;
      c.strokeRect(x + 2, y + 2, s - 4, s - 4);
      // 3x3 grid lines
      c.beginPath();
      c.moveTo(x + 11, y + 2); c.lineTo(x + 11, y + s - 2);
      c.moveTo(x + 21, y + 2); c.lineTo(x + 21, y + s - 2);
      c.moveTo(x + 2, y + 11); c.lineTo(x + s - 2, y + 11);
      c.moveTo(x + 2, y + 21); c.lineTo(x + s - 2, y + 21);
      c.stroke();
    });

    // 29. Crafting Table Side
    register('crafting_table_side', (c, x, y, s) => {
      c.fillStyle = '#b8945f';
      c.fillRect(x, y, s, s);
      // tools hanging
      c.fillStyle = '#5c3e21';
      c.fillRect(x + 6, y + 8, 8, 16);
      c.fillStyle = '#8b8b8b';
      c.fillRect(x + 6, y + 6, 8, 4);
    });

    // 30. Crafting Table Front
    register('crafting_table_front', (c, x, y, s) => {
      c.fillStyle = '#b8945f';
      c.fillRect(x, y, s, s);
      // Saw & hammer graphic
      c.fillStyle = '#7a7a7a';
      c.fillRect(x + 6, y + 10, 10, 14);
      c.fillStyle = '#866043';
      c.fillRect(x + 18, y + 12, 6, 12);
    });

    // 31. Furnace Top
    register('furnace_top', (c, x, y, s) => {
      c.fillStyle = '#7d7d7d';
      c.fillRect(x, y, s, s);
      c.strokeStyle = '#525252';
      c.strokeRect(x + 3, y + 3, s - 6, s - 6);
    });

    // 32. Furnace Side
    register('furnace_side', (c, x, y, s) => {
      c.fillStyle = '#7d7d7d';
      c.fillRect(x, y, s, s);
      for (let py = 0; py < s; py += 4) {
        c.fillStyle = '#636363';
        c.fillRect(x, y + py, s, 1);
      }
    });

    // 33. Furnace Front
    register('furnace_front', (c, x, y, s) => {
      c.fillStyle = '#7d7d7d';
      c.fillRect(x, y, s, s);
      // Opening
      c.fillStyle = '#222222';
      c.fillRect(x + 6, y + 14, s - 12, 12);
      c.fillStyle = '#d94b18'; // hot coals
      c.fillRect(x + 8, y + 20, s - 16, 4);
      c.fillStyle = '#fcae1e';
      c.fillRect(x + 10, y + 21, 6, 2);
    });

    // 34. Glowstone
    register('glowstone', (c, x, y, s) => {
      c.fillStyle = '#cca34a';
      c.fillRect(x, y, s, s);
      for (let py = 0; py < s; py += 2) {
        for (let px = 0; px < s; px += 2) {
          const r = seedNoise(x + px, y + py);
          c.fillStyle = r > 0.6 ? '#fce78d' : r > 0.3 ? '#e0be5a' : '#a87a2c';
          c.fillRect(x + px, y + py, 2, 2);
        }
      }
    });

    // 35. Snow Top
    register('snow', (c, x, y, s) => {
      c.fillStyle = '#ffffff';
      c.fillRect(x, y, s, s);
      for (let py = 0; py < s; py += 2) {
        for (let px = 0; px < s; px += 2) {
          const r = seedNoise(x + px, y + py);
          c.fillStyle = r > 0.7 ? '#e3f1f7' : r > 0.4 ? '#edf6fa' : '#ffffff';
          c.fillRect(x + px, y + py, 2, 2);
        }
      }
    });

    // 36. Snow Side
    register('snow_side', (c, x, y, s) => {
      c.fillStyle = '#866043';
      c.fillRect(x, y, s, s);
      // Top snow layer
      c.fillStyle = '#ffffff';
      c.fillRect(x, y, s, 8);
      for (let px = 0; px < s; px += 2) {
        const drop = Math.floor(seedNoise(x + px, y) * 8) + 4;
        c.fillRect(x + px, y, 2, drop);
      }
    });

    // 37. Birch Log Top
    register('log_birch_top', (c, x, y, s) => {
      c.fillStyle = '#d7cfb5';
      c.fillRect(x, y, s, s);
      c.strokeStyle = '#baa67e';
      c.strokeRect(x + 4, y + 4, s - 8, s - 8);
      c.strokeRect(x + 8, y + 8, s - 16, s - 16);
    });

    // 38. Birch Log Side
    register('log_birch', (c, x, y, s) => {
      c.fillStyle = '#e8e5db';
      c.fillRect(x, y, s, s);
      // horizontal black marks
      const marks = [[4, 6, 8, 2], [18, 14, 6, 2], [8, 22, 10, 3], [22, 26, 6, 2]];
      marks.forEach(([mx, my, mw, mh]) => {
        c.fillStyle = '#262624';
        c.fillRect(x + mx, y + my, mw, mh);
      });
    });

    // 39. Birch Leaves
    register('leaves_birch', (c, x, y, s) => {
      c.fillStyle = '#5ca843';
      c.fillRect(x, y, s, s);
      for (let py = 0; py < s; py += 2) {
        for (let px = 0; px < s; px += 2) {
          const r = seedNoise(x + px, y + py);
          if (r > 0.8) c.clearRect(x + px, y + py, 2, 2);
          else if (r > 0.5) {
            c.fillStyle = '#77c45c';
            c.fillRect(x + px, y + py, 2, 2);
          } else {
            c.fillStyle = '#489431';
            c.fillRect(x + px, y + py, 2, 2);
          }
        }
      }
    });

    // 40. Mossy Cobblestone
    register('mossy_cobblestone', (c, x, y, s) => {
      c.fillStyle = '#525252';
      c.fillRect(x, y, s, s);
      for (let py = 0; py < s; py += 2) {
        for (let px = 0; px < s; px += 2) {
          const r = seedNoise(x + px, y + py);
          c.fillStyle = r > 0.6 ? '#476930' : r > 0.4 ? '#8a8a8a' : '#636363';
          c.fillRect(x + px, y + py, 2, 2);
        }
      }
    });

    // 41. Obsidian
    register('obsidian', (c, x, y, s) => {
      c.fillStyle = '#120c1f';
      c.fillRect(x, y, s, s);
      for (let py = 0; py < s; py += 2) {
        for (let px = 0; px < s; px += 2) {
          const r = seedNoise(x + px, y + py);
          c.fillStyle = r > 0.8 ? '#36245c' : r > 0.4 ? '#1d1430' : '#0c0714';
          c.fillRect(x + px, y + py, 2, 2);
        }
      }
    });

    // 42. Flower Red
    register('flower_red', (c, x, y, s) => {
      c.clearRect(x, y, s, s);
      // stem
      c.fillStyle = '#3a8726';
      c.fillRect(x + 15, y + 12, 2, 18);
      c.fillRect(x + 13, y + 18, 2, 4);
      // petals
      c.fillStyle = '#e81717';
      c.fillRect(x + 12, y + 6, 8, 8);
      c.fillStyle = '#ff4d4d';
      c.fillRect(x + 14, y + 8, 4, 4);
      c.fillStyle = '#1a1a1a';
      c.fillRect(x + 15, y + 9, 2, 2);
    });

    // 43. Flower Yellow
    register('flower_yellow', (c, x, y, s) => {
      c.clearRect(x, y, s, s);
      // stem
      c.fillStyle = '#3a8726';
      c.fillRect(x + 15, y + 14, 2, 16);
      // flower
      c.fillStyle = '#ffde17';
      c.fillRect(x + 12, y + 8, 8, 8);
      c.fillStyle = '#ffaa00';
      c.fillRect(x + 14, y + 10, 4, 4);
    });

    // Tools & Item icons for 2D UI
    this.createItemIcons();

    // Create Three.js Texture
    const atlasTex = new THREE.CanvasTexture(canvas);
    atlasTex.magFilter = THREE.NearestFilter;
    atlasTex.minFilter = THREE.NearestFilter;
    atlasTex.colorSpace = THREE.SRGBColorSpace;
    this.atlasTexture = atlasTex;
  }

  private generateCracks() {
    const S = 32;
    for (let stage = 0; stage < 10; stage++) {
      const canvas = document.createElement('canvas');
      canvas.width = S;
      canvas.height = S;
      const ctx = canvas.getContext('2d')!;
      ctx.clearRect(0, 0, S, S);

      ctx.strokeStyle = 'rgba(0, 0, 0, 0.75)';
      ctx.lineWidth = 2;
      ctx.beginPath();

      const numLines = (stage + 1) * 3;
      for (let i = 0; i < numLines; i++) {
        const x1 = Math.sin(i * 1.5 + stage) * (S / 2) + S / 2;
        const y1 = Math.cos(i * 1.8 + stage) * (S / 2) + S / 2;
        const x2 = Math.sin(i * 2.3 + stage) * (S / 2) + S / 2;
        const y2 = Math.cos(i * 2.7 + stage) * (S / 2) + S / 2;
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
      }
      ctx.stroke();

      const tex = new THREE.CanvasTexture(canvas);
      tex.magFilter = THREE.NearestFilter;
      tex.minFilter = THREE.NearestFilter;
      this.crackTextures.push(tex);
    }
  }

  private createItemIcons() {
    const createToolIcon = (id: string, matColor: string, type: string) => {
      const canvas = document.createElement('canvas');
      canvas.width = 32;
      canvas.height = 32;
      const c = canvas.getContext('2d')!;
      c.imageSmoothingEnabled = false;

      // Handle stick
      c.fillStyle = '#866043';
      for (let i = 0; i < 14; i++) {
        c.fillRect(8 + i, 22 - i, 2, 2);
      }

      c.fillStyle = matColor;
      if (type === 'pickaxe') {
        c.fillRect(18, 6, 8, 4);
        c.fillRect(24, 8, 4, 8);
        c.fillRect(12, 6, 8, 3);
        c.fillRect(8, 8, 4, 6);
      } else if (type === 'axe') {
        c.fillRect(16, 6, 10, 8);
        c.fillRect(14, 8, 4, 8);
      } else if (type === 'shovel') {
        c.fillRect(18, 6, 8, 8);
        c.fillRect(20, 4, 4, 4);
      } else if (type === 'sword') {
        for (let i = 0; i < 12; i++) {
          c.fillRect(14 + i, 16 - i, 4, 4);
        }
        c.fillStyle = '#4a3219';
        c.fillRect(12, 18, 6, 2);
        c.fillRect(10, 16, 2, 6);
      }

      this.itemIcons[id] = canvas.toDataURL('image/png');
    };

    const materials = [
      { name: 'wooden', color: '#b8945f' },
      { name: 'stone', color: '#888888' },
      { name: 'iron', color: '#e0e0e0' },
      { name: 'diamond', color: '#4bede6' }
    ];

    materials.forEach(m => {
      createToolIcon(`item_${m.name}_pickaxe`, m.color, 'pickaxe');
      createToolIcon(`item_${m.name}_axe`, m.color, 'axe');
      createToolIcon(`item_${m.name}_shovel`, m.color, 'shovel');
      createToolIcon(`item_${m.name}_sword`, m.color, 'sword');
    });

    // Sticks, Ores, Diamond, Coal icons
    const createResourceIcon = (id: string, color: string, isRound = false) => {
      const canvas = document.createElement('canvas');
      canvas.width = 32;
      canvas.height = 32;
      const c = canvas.getContext('2d')!;
      c.fillStyle = color;
      if (isRound) {
        c.beginPath();
        c.arc(16, 16, 10, 0, Math.PI * 2);
        c.fill();
      } else {
        c.fillRect(8, 8, 16, 16);
      }
      this.itemIcons[id] = canvas.toDataURL('image/png');
    };

    createResourceIcon('item_coal', '#262626');
    createResourceIcon('item_raw_iron', '#d1d1d1');
    createResourceIcon('item_raw_gold', '#fcd836');
    createResourceIcon('item_diamond', '#4bede6');
    createResourceIcon('item_redstone', '#e62424', true);
    createResourceIcon('item_apple', '#d92727', true);
    createResourceIcon('item_porkchop', '#e87d7d');
    createResourceIcon('item_stick', '#866043');
  }

  // Get UV coordinates [u0, v0, u1, v1] for a texture name
  public getUV(textureName: string): [number, number, number, number] {
    const index = this.textureIndices[textureName] ?? 0;
    const tileX = index % this.atlasTilesX;
    const tileY = Math.floor(index / this.atlasTilesX);

    const u0 = tileX / this.atlasTilesX;
    const u1 = (tileX + 1) / this.atlasTilesX;
    const v1 = 1 - (tileY / this.atlasTilesY);
    const v0 = 1 - ((tileY + 1) / this.atlasTilesY);

    return [u0, v0, u1, v1];
  }
}
